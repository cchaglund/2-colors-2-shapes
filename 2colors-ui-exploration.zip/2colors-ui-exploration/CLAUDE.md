# 2colors UI Exploration

## Process Cleanup

- Always stop background processes (e.g. dev servers) when you're done with them
- Before ending a session or moving on from a task that required a running server, kill the process
- Use `kill` or similar to stop processes started with `&` or `run_in_background`
