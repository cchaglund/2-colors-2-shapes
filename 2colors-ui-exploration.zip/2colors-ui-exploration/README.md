# 2colors UI Exploration

A UI/UX design exploration for **2colors** — a daily art creation app where users compose small pieces using a constrained palette (3 colors, 2 shapes, 800x800 canvas, daily inspiration word).

## Scope

This project is strictly a **frontend UI exploration**. The goal is to experiment with layout, interaction patterns, visual design, and micro-interactions for the canvas editor view.

**What's in scope:**

- Visual design and theming (light/dark mode, color tokens, typography)
- Interactive UI elements — buttons, toggles, panels, modals are all clickable and functional at the UI layer
- Transitions and animations (panel open/close, shape placement, hover states)
- Layout iteration — toolbar positioning, floating panels, canvas controls
- Canvas interactions — placing shapes, zooming, panning, layer management

**What's NOT in scope:**

- Backend, API, or data persistence — nothing is saved
- Authentication — the login modal opens but doesn't connect to anything
- Gallery — shows placeholder content only
- Real canvas rendering (WebGL/Canvas API) — shapes are DOM elements for prototyping purposes

## Running

```
npm install
npm run dev
```

Opens on [http://localhost:4000](http://localhost:4000).

## Stack

- Vite + React + TypeScript
- Tailwind CSS v4
- Motion (Framer Motion) for animations
- All styling via inline React styles (no CSS modules)
