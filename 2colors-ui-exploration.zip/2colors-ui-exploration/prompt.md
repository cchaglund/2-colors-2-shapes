I am building a fun web application that lets users create small pieces of art every day. They have limited options - 3 possible colors and 2 possible shapes on a 800x800 canvas (they can also change the background color to one of the available 3 colors). There is also a random word each day for inspiration. Every day is a new challenge - the colors, shapes, and inspiration word changes daily, encouraging users to think creatively within constraints. The users can submit their artwork which will a) save it in their personal gallery (calendar view where they see each day's creation) and b) share it with the community. The community then votes on their favorite pieces. I want it to be immediately obvious how to use, with a simple and intuitive interface. 

This is just a design/ui exploration, so we won't worry about the backend, data storage, user accounts, the voting system, word/shape/color generation (user hardcoded values), or the calendar view for now. We will just focus on the canvas view and the user interface for creating art. We don't even need to implement the actual drawing/photoshop/figma-like functionality - we just use simple HTML/CSS/JS to create a mockup of the interface and the canvas.

Here's a breakdown of the features we eventually will have in the canvas view, so these should be available in the design:

- user should be able to add one of the two daily shapes (let's say a circle and a square) to the canvas
- they will need to choose one of the three daily colors for the shapes
- exactly how this is done is up to you - e.g. should there be individual buttons each shape + color combo (six buttons!), or should there be a dropdown for shapes and another for colors, or some other method? Think creatively, and ease of use. Affordances should be clear and the interface should be intuitive.
- users should be able to change the background color of the canvas to one of the three daily colors
- there should be a clear way to submit their artwork once they are done (e.g. a "Submit" button)
- there should be a clear way to reset the canvas if they want to start over (e.g. a "Reset" button)
- the daily inspiration word should be prominently displayed on the canvas view to encourage creativity.
- the user should be able to login
- there should be some way to view the gallery, which is comprised of their own submissions, winners, other contributors' submissions, and their friends' submissions. You do not need to implement the actual gallery view, but there should be a clear way to access it, as it's an important part of the user experience.
- users should be able to zoom and pan the canvas
- there should be available some power tools, even though they a) shouldn't overwhelm the user (and as such should be optional to use - hidden initially, but also easily accessible and findable when the user feels themselves wishing for more advanced features) and b) shouldn't actually be functional in this mockup (e.g. they can be buttons that don't do anything when clicked, but they should be designed in a way that makes it clear what they would do if they were functional). Primarily there are two groups of powertools: 1) a layering panel that allows users to manage the layers of their artwork (e.g. move shapes up/down, delete shapes, etc.) and 2) a toolbar with options to e.g. undo/redo actions, duplicate shapes, and change shape properties (e.g. size, rotation, etc.). These power tools should be designed in a way that they are easily discoverable when the user is ready for them, but they should not be overwhelming or distracting for users who just want to create simple art with the basic features.

The app should be visually appealing and fun to use, with a playful and creative vibe. The design should encourage users to experiment and have fun with the constraints, while also providing enough tools and options for those who want to dive deeper into their creativity.

Your task is to build an incredible mockup of the canvas view of this application, where users create their art. This should be a static design/mockup using HTML/CSS/JS. I want it to be creative and unique. Really push the limits of your design capabilities. 

You have an empty directory here, I want you to initialize a project with the following specs:

- vite
- react
- typescript
- tailwind
- node

Once initialized, I want you to create FIVE different designs. Each design should be creative and unique from all the others you create. They should be hosted on /1, /2, /3, /4/, and /5 respectively. 

Use the "frontend-design" skill.

Use the following port for the development server: 4000.

