import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Design2 from './designs/Design2'
import Gallery from './Gallery'
import SubmissionDetail from './SubmissionDetail'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Design2 />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/gallery/:id" element={<SubmissionDetail />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
