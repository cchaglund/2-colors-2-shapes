import type { MockSubmission } from './mockData'

// Renders a procedurally generated artwork from submission shapes
export default function ArtThumbnail({
  submission,
  size = 120,
  style,
  onClick,
}: {
  submission: MockSubmission
  size?: number | string
  style?: React.CSSProperties
  onClick?: () => void
}) {
  return (
    <div
      onClick={onClick}
      style={{
        width: size,
        height: size,
        background: submission.bgColor,
        position: 'relative',
        overflow: 'hidden',
        cursor: onClick ? 'pointer' : undefined,
        ...style,
      }}
    >
      {submission.shapes.map((shape, i) => (
        <div
          key={i}
          style={{
            position: 'absolute',
            left: `${shape.x}%`,
            top: `${shape.y}%`,
            width: `${shape.size}%`,
            height: `${shape.size}%`,
            background: shape.color,
            borderRadius: shape.type === 'circle' ? '50%' : '2px',
            transform: `translate(-50%, -50%) rotate(${shape.rotation}deg)`,
          }}
        />
      ))}
    </div>
  )
}
