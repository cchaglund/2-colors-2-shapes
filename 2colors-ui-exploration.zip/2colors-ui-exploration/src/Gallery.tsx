import { useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'motion/react'
import {
  type ThemeId,
  THEME_LABELS,
  DAILY_COLORS,
  useThemeVars,
  getAccentTextColor,
} from './shared'
import ArtThumbnail from './ArtThumbnail'
import {
  getCalendarDays,
  getUserSubmission,
  getUserSubmissionCount,
  getUserTrophies,
  getWinner,
  getWinnerCount,
  getSubmissionsForDay,
  getDayStatus,
  getFriendSubmissions,
  getAllFriendSubmissions,
  type MockSubmission,
} from './mockData'

type GalleryTab = 'mine' | 'winners' | 'wall' | 'friends'
type ViewMode = 'calendar' | 'grid'

const TAB_CONFIG: { id: GalleryTab; label: string; hasGrid: boolean }[] = [
  { id: 'mine', label: 'My Submissions', hasGrid: false },
  { id: 'winners', label: 'Winners', hasGrid: false },
  { id: 'wall', label: 'Wall', hasGrid: true },
  { id: 'friends', label: 'Friends', hasGrid: true },
]

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
]

const DAY_HEADERS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

const SORT_OPTIONS = ['Newest', 'Oldest', 'Random']

export default function Gallery() {
  const [darkMode, setDarkMode] = useState(() => {
    return document.documentElement.getAttribute('data-mode') === 'dark'
  })
  const [themeId, setThemeId] = useState<ThemeId>(() => {
    return (document.documentElement.getAttribute('data-theme') as ThemeId) || 'a'
  })
  const t = useThemeVars(darkMode, themeId)
  const navigate = useNavigate()

  const accentTextColor = getAccentTextColor(themeId)

  const [activeTab, setActiveTab] = useState<GalleryTab>('mine')
  const [viewMode, setViewMode] = useState<ViewMode>('calendar')
  const [sortBy, setSortBy] = useState('Newest')

  const today = new Date()
  const [viewYear, setViewYear] = useState(today.getFullYear())
  const [viewMonth, setViewMonth] = useState(today.getMonth() + 1)

  // For Wall grid view: navigate by day
  const [wallDay, setWallDay] = useState(today.getDate())
  const [wallMonth, setWallMonth] = useState(today.getMonth() + 1)
  const [wallYear, setWallYear] = useState(today.getFullYear())

  const calendarDays = useMemo(() => getCalendarDays(viewYear, viewMonth), [viewYear, viewMonth])

  const prevMonth = () => {
    if (viewMonth === 1) { setViewMonth(12); setViewYear(y => y - 1) }
    else setViewMonth(m => m - 1)
  }
  const nextMonth = () => {
    if (viewMonth === 12) { setViewMonth(1); setViewYear(y => y + 1) }
    else setViewMonth(m => m + 1)
  }

  const prevDay = () => {
    const d = new Date(wallYear, wallMonth - 1, wallDay - 1)
    setWallDay(d.getDate())
    setWallMonth(d.getMonth() + 1)
    setWallYear(d.getFullYear())
  }
  const nextDay = () => {
    const d = new Date(wallYear, wallMonth - 1, wallDay + 1)
    if (d > today) return
    setWallDay(d.getDate())
    setWallMonth(d.getMonth() + 1)
    setWallYear(d.getFullYear())
  }
  const goToday = () => {
    setWallDay(today.getDate())
    setWallMonth(today.getMonth() + 1)
    setWallYear(today.getFullYear())
  }

  const handleTabChange = (tab: GalleryTab) => {
    setActiveTab(tab)
    // Reset to calendar when switching to a tab that doesn't have grid
    if (!TAB_CONFIG.find(t => t.id === tab)?.hasGrid) {
      setViewMode('calendar')
    }
  }

  const isToday = (day: number) => {
    return viewYear === today.getFullYear() && viewMonth === today.getMonth() + 1 && day === today.getDate()
  }

  const navigateToSubmission = (sub: MockSubmission) => {
    navigate(`/gallery/${sub.id}`)
  }

  const currentTabHasGrid = TAB_CONFIG.find(t => t.id === activeTab)?.hasGrid ?? false

  // ===== Render helpers =====

  const renderCalendarCell = (day: number | null, idx: number) => {
    if (day === null) return <div key={`empty-${idx}`} style={{ aspectRatio: '1' }} />

    const isTodayCell = isToday(day)
    const isFuture = new Date(viewYear, viewMonth - 1, day) > today

    if (activeTab === 'mine') return renderMySubmissionCell(day, isTodayCell, isFuture)
    if (activeTab === 'winners') return renderWinnerCell(day, isTodayCell, isFuture)
    if (activeTab === 'wall') return renderWallCalendarCell(day, isTodayCell, isFuture)
    if (activeTab === 'friends') return renderFriendsCalendarCell(day, isTodayCell, isFuture)
    return null
  }

  const renderMySubmissionCell = (day: number, isTodayCell: boolean, isFuture: boolean) => {
    const sub = getUserSubmission(viewYear, viewMonth, day)

    return (
      <motion.div
        key={`day-${day}`}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: day * 0.008, duration: 0.2 }}
        onClick={() => sub && navigateToSubmission(sub)}
        style={{
          aspectRatio: '1',
          border: isTodayCell ? `2px solid ${t.accent}` : `1px solid ${t.borderLight}`,
          borderRadius: t.radiusSm,
          position: 'relative',
          overflow: 'hidden',
          cursor: sub ? 'pointer' : 'default',
          opacity: isFuture ? 0.3 : 1,
          transition: 'transform 0.15s, box-shadow 0.15s',
        }}
        whileHover={sub ? { scale: 1.03, boxShadow: t._cardShadow() } : {}}
      >
        {/* Day number badge */}
        {sub && (
          <div style={{
            position: 'absolute', top: 4, left: 4, zIndex: 2,
            background: t.accent, color: accentTextColor,
            fontSize: 9, fontWeight: 800,
            width: 20, height: 20, borderRadius: t.radiusSm,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
          }}>
            {day}
          </div>
        )}

        {sub ? (
          <ArtThumbnail submission={sub} size="100%" />
        ) : (
          <div style={{
            width: '100%', height: '100%',
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center',
            gap: 4,
          }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: t.textMuted }}>{day}</div>
            {!isFuture && !isTodayCell && (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--border-light)" strokeWidth="1.5" strokeLinecap="round" opacity={0.5}>
                <path d="M18 6L6 18M6 6l12 12"/>
              </svg>
            )}
            {isTodayCell && (
              <div style={{ fontSize: 8, fontWeight: 700, color: t.accent, letterSpacing: 0.5, textTransform: 'uppercase' }}>
                Create!
              </div>
            )}
          </div>
        )}

        {/* Trophy indicator for winning submissions */}
        {sub && sub.rank === 1 && (
          <div style={{
            position: 'absolute', bottom: 3, right: 3, fontSize: 12,
            background: 'rgba(255,255,255,0.9)', borderRadius: '50%',
            width: 20, height: 20, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            🏆
          </div>
        )}
      </motion.div>
    )
  }

  const renderWinnerCell = (day: number, isTodayCell: boolean, isFuture: boolean) => {
    const winner = getWinner(viewYear, viewMonth, day)
    const todayDate = new Date()
    const cellDate = new Date(viewYear, viewMonth - 1, day)
    const daysDiff = Math.floor((todayDate.getTime() - cellDate.getTime()) / (1000 * 60 * 60 * 24))
    const isVoting = daysDiff === 1
    const isCreating = isTodayCell

    return (
      <motion.div
        key={`winner-${day}`}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: day * 0.008, duration: 0.2 }}
        onClick={() => winner && navigateToSubmission(winner)}
        style={{
          aspectRatio: '1',
          border: isTodayCell ? `2px solid ${t.accent}` : `1px solid ${t.borderLight}`,
          borderRadius: t.radiusSm,
          position: 'relative',
          overflow: 'hidden',
          cursor: winner ? 'pointer' : 'default',
          opacity: isFuture ? 0.3 : 1,
        }}
        whileHover={winner ? { scale: 1.03, boxShadow: t._cardShadow() } : {}}
      >
        {winner && (
          <div style={{
            position: 'absolute', top: 4, left: 4, zIndex: 2,
            background: '#FFD700', color: '#5C4200',
            fontSize: 9, fontWeight: 800,
            width: 20, height: 20, borderRadius: t.radiusSm,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
          }}>
            {day}
          </div>
        )}

        {winner ? (
          <ArtThumbnail submission={winner} size="100%" />
        ) : (
          <div style={{
            width: '100%', height: '100%',
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center',
            gap: 2,
          }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: t.textMuted }}>{day}</div>
            <div style={{
              fontSize: 9, color: t.textMuted, fontWeight: 500,
              fontStyle: (isCreating || isVoting) ? 'italic' : 'normal',
              opacity: isFuture ? 0 : 0.6,
            }}>
              {isCreating ? 'Creating...' : isVoting ? 'Voting...' : isFuture ? '' : 'No winner'}
            </div>
          </div>
        )}

        {/* Crown on winners */}
        {winner && (
          <div style={{
            position: 'absolute', bottom: 3, right: 3, fontSize: 12,
            background: 'rgba(255,215,0,0.9)', borderRadius: '50%',
            width: 20, height: 20, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            👑
          </div>
        )}
      </motion.div>
    )
  }

  const renderWallCalendarCell = (day: number, isTodayCell: boolean, isFuture: boolean) => {
    const status = getDayStatus(viewYear, viewMonth, day)

    return (
      <motion.div
        key={`wall-${day}`}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: day * 0.008, duration: 0.2 }}
        onClick={() => {
          if (!isFuture && status.count > 0) {
            setViewMode('grid')
            setWallDay(day)
            setWallMonth(viewMonth)
            setWallYear(viewYear)
          }
        }}
        style={{
          aspectRatio: '1',
          border: isTodayCell ? `2px solid ${t.accent}` : `1px solid ${t.borderLight}`,
          borderRadius: t.radiusSm,
          position: 'relative',
          overflow: 'hidden',
          cursor: status.count > 0 ? 'pointer' : 'default',
          opacity: isFuture ? 0.3 : 1,
          display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
        }}
        whileHover={status.count > 0 ? { scale: 1.03 } : {}}
      >
        <div style={{ fontSize: 10, fontWeight: 600, color: t.textMuted, marginBottom: 4 }}>{day}</div>

        {status.count > 0 ? (
          <WallCalendarBubble count={status.count} colors={status.colors} t={t} />
        ) : isTodayCell ? (
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2" strokeLinecap="round" opacity={0.5}>
            <rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/>
          </svg>
        ) : status.status === 'voting' ? (
          <div style={{ fontSize: 8, color: t.textMuted, fontStyle: 'italic' }}>Voting</div>
        ) : null}
      </motion.div>
    )
  }

  const renderFriendsCalendarCell = (day: number, isTodayCell: boolean, isFuture: boolean) => {
    const friendSubs = getFriendSubmissions(viewYear, viewMonth, day)
    const count = friendSubs.length

    return (
      <motion.div
        key={`friends-cal-${day}`}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: day * 0.008, duration: 0.2 }}
        onClick={() => {
          if (count > 0) {
            setViewMode('grid')
            setWallDay(day)
            setWallMonth(viewMonth)
            setWallYear(viewYear)
          }
        }}
        style={{
          aspectRatio: '1',
          border: isTodayCell ? `2px solid ${t.accent}` : `1px solid ${t.borderLight}`,
          borderRadius: t.radiusSm,
          position: 'relative',
          overflow: 'hidden',
          cursor: count > 0 ? 'pointer' : 'default',
          opacity: isFuture ? 0.3 : 1,
          display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
        }}
        whileHover={count > 0 ? { scale: 1.03 } : {}}
      >
        <div style={{ fontSize: 10, fontWeight: 600, color: t.textMuted, marginBottom: 4 }}>{day}</div>

        {count > 0 ? (
          <div style={{
            display: 'flex', gap: 2, flexWrap: 'wrap',
            justifyContent: 'center', maxWidth: '80%',
          }}>
            {friendSubs.slice(0, 4).map((sub, i) => (
              <div key={i} style={{
                width: count > 2 ? 14 : 18,
                height: count > 2 ? 14 : 18,
                borderRadius: '50%',
                background: sub.bgColor,
                border: `1.5px solid ${t.borderLight}`,
                overflow: 'hidden',
              }}>
                <ArtThumbnail submission={sub} size="100%" />
              </div>
            ))}
          </div>
        ) : null}
      </motion.div>
    )
  }

  // ===== Grid views =====

  const renderWallGrid = () => {
    const subs = getSubmissionsForDay(wallYear, wallMonth, wallDay)
    let sorted = [...subs]
    if (sortBy === 'Oldest') sorted.reverse()
    if (sortBy === 'Random') sorted.sort(() => Math.random() - 0.5)

    const dateObj = new Date(wallYear, wallMonth - 1, wallDay)
    const formatted = dateObj.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })

    return (
      <div>
        {/* Day navigation */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          gap: 16, marginBottom: 20,
        }}>
          <button onClick={prevDay} style={navArrowStyle(t)}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M15 18l-6-6 6-6"/></svg>
          </button>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 18, color: t.text, fontWeight: 700 }}>
            {formatted}
          </div>
          <button onClick={goToday} style={{
            background: t.selected, border: `${t.borderW} solid ${t.borderLight}`,
            borderRadius: t.radiusPill, padding: '4px 12px',
            fontSize: 11, fontWeight: 600, color: t.text,
            cursor: 'pointer', fontFamily: 'inherit',
          }}>
            Today
          </button>
          <button
            onClick={nextDay}
            style={{
              ...navArrowStyle(t),
              opacity: new Date(wallYear, wallMonth - 1, wallDay + 1) > today ? 0.3 : 1,
            }}
            disabled={new Date(wallYear, wallMonth - 1, wallDay + 1) > today}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M9 18l6-6-6-6"/></svg>
          </button>
        </div>

        {/* Sort + View toggle */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          marginBottom: 16,
        }}>
          {renderViewToggle()}
          <div style={{ position: 'relative' }}>
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value)}
              style={{
                background: t.surface, border: `${t.borderW} solid ${t.borderLight}`,
                borderRadius: t.radiusMd, padding: '6px 28px 6px 12px',
                fontSize: 12, fontWeight: 600, color: t.text,
                cursor: 'pointer', fontFamily: 'inherit',
                appearance: 'none', outline: 'none',
              }}
            >
              {SORT_OPTIONS.map(opt => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"
              style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', color: t.textMuted }}>
              <path d="M6 9l6 6 6-6"/>
            </svg>
          </div>
        </div>

        {/* Grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))',
          gap: 16,
        }}>
          <AnimatePresence mode="popLayout">
            {sorted.map((sub, i) => (
              <motion.div
                key={sub.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: i * 0.03, type: 'spring', stiffness: 400, damping: 25 }}
              >
                <SubmissionCard
                  submission={sub}
                  t={t}
                  themeId={themeId}
                  onClick={() => navigateToSubmission(sub)}
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {sorted.length === 0 && (
          <EmptyState message="No submissions for this day yet" t={t} />
        )}
      </div>
    )
  }

  const renderFriendsGrid = () => {
    const subs = activeTab === 'friends' && viewMode === 'grid'
      ? getAllFriendSubmissions(viewYear, viewMonth)
      : []

    let sorted = [...subs]
    if (sortBy === 'Oldest') sorted.reverse()
    if (sortBy === 'Random') sorted.sort(() => Math.random() - 0.5)

    return (
      <div>
        {/* Sort + view toggle */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          marginBottom: 16,
        }}>
          {renderViewToggle()}
          <div style={{ position: 'relative' }}>
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value)}
              style={{
                background: t.surface, border: `${t.borderW} solid ${t.borderLight}`,
                borderRadius: t.radiusMd, padding: '6px 28px 6px 12px',
                fontSize: 12, fontWeight: 600, color: t.text,
                cursor: 'pointer', fontFamily: 'inherit',
                appearance: 'none', outline: 'none',
              }}
            >
              {SORT_OPTIONS.map(opt => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"
              style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', color: t.textMuted }}>
              <path d="M6 9l6 6 6-6"/>
            </svg>
          </div>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))',
          gap: 16,
        }}>
          <AnimatePresence mode="popLayout">
            {sorted.map((sub, i) => (
              <motion.div
                key={sub.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: i * 0.03, type: 'spring', stiffness: 400, damping: 25 }}
              >
                <SubmissionCard
                  submission={sub}
                  t={t}
                  themeId={themeId}
                  onClick={() => navigateToSubmission(sub)}
                  showDate
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {sorted.length === 0 && (
          <EmptyState message="No friend submissions this month" t={t} />
        )}
      </div>
    )
  }

  const renderViewToggle = () => {
    if (!currentTabHasGrid) return <div />
    return (
      <div style={{
        display: 'flex',
        background: t.selected,
        borderRadius: t.radiusMd,
        border: `${t.borderW} solid ${t.borderLight}`,
        padding: 2,
      }}>
        {(['grid', 'calendar'] as ViewMode[]).map(mode => (
          <button
            key={mode}
            onClick={() => setViewMode(mode)}
            style={{
              background: viewMode === mode ? t.surface : 'transparent',
              border: viewMode === mode ? `${t.borderW} solid ${t.borderLight}` : '1px solid transparent',
              borderRadius: t.radiusSm,
              padding: '5px 14px',
              fontSize: 11, fontWeight: 700, color: viewMode === mode ? t.text : t.textMuted,
              cursor: 'pointer', fontFamily: 'inherit',
              textTransform: 'capitalize',
              boxShadow: viewMode === mode ? t.btnShadow : 'none',
              transition: 'all 0.15s',
            }}
          >
            {mode === 'grid' ? (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" style={{ verticalAlign: 'middle', marginRight: 5 }}>
                <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
                <rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>
              </svg>
            ) : (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" style={{ verticalAlign: 'middle', marginRight: 5 }}>
                <rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/>
              </svg>
            )}
            {mode}
          </button>
        ))}
      </div>
    )
  }

  // ===== Footer stats =====

  const renderFooter = () => {
    if (activeTab === 'mine') {
      const count = getUserSubmissionCount(viewYear, viewMonth)
      const trophies = getUserTrophies(viewYear, viewMonth)
      return (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            padding: '16px 0 0',
            borderTop: `1px solid ${t.borderLight}`,
            marginTop: 24,
          }}
        >
          <div style={{ fontSize: 13, fontWeight: 600, color: t.textMuted }}>
            Total submissions: <span style={{ color: t.text, fontWeight: 700 }}>{count}</span>
          </div>
          <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
            {trophies.gold > 0 && (
              <span style={{ fontSize: 12, display: 'flex', alignItems: 'center', gap: 3 }}>
                🥇 <span style={{ fontWeight: 700, color: t.text }}>×{trophies.gold}</span>
              </span>
            )}
            {trophies.silver > 0 && (
              <span style={{ fontSize: 12, display: 'flex', alignItems: 'center', gap: 3 }}>
                🥈 <span style={{ fontWeight: 700, color: t.text }}>×{trophies.silver}</span>
              </span>
            )}
            {trophies.bronze > 0 && (
              <span style={{ fontSize: 12, display: 'flex', alignItems: 'center', gap: 3 }}>
                🥉 <span style={{ fontWeight: 700, color: t.text }}>×{trophies.bronze}</span>
              </span>
            )}
          </div>
        </motion.div>
      )
    }

    if (activeTab === 'winners') {
      const { total, unique } = getWinnerCount(viewYear, viewMonth)
      return (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            padding: '16px 0 0',
            borderTop: `1px solid ${t.borderLight}`,
            marginTop: 24,
          }}
        >
          <div style={{ fontSize: 13, fontWeight: 600, color: t.textMuted }}>
            Winners this month: <span style={{ color: t.text, fontWeight: 700 }}>{total}</span>
          </div>
          <div style={{ fontSize: 13, fontWeight: 600, color: t.textMuted }}>
            <span style={{ color: t.text, fontWeight: 700 }}>{unique}</span> unique winners
          </div>
        </motion.div>
      )
    }

    return null
  }

  // ===== Main render =====

  return (
    <div style={{
      width: '100vw', height: '100vh', background: t.bg,
      fontFamily: t.fontBody, color: t.text,
      display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative',
      transition: `background var(--theme-transition), color var(--theme-transition)`,
    }}>
      <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@300;400;500;600;700&family=Lilita+One&family=DM+Sans:wght@300;400;500;600;700&family=Nunito:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet" />

      {/* Background pattern */}
      <div style={{
        position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0,
        opacity: t.patternOpacity,
        backgroundImage: themeId === 'a'
          ? `radial-gradient(circle at 20px 20px, #FF3366 2px, transparent 2px), radial-gradient(circle at 60px 60px, #33CCFF 1.5px, transparent 1.5px)`
          : themeId === 'c'
            ? `radial-gradient(circle at 30px 30px, rgba(157, 196, 176, 0.18) 3px, transparent 3px), radial-gradient(circle at 70px 70px, rgba(224, 122, 95, 0.1) 4px, transparent 4px)`
            : 'none',
        backgroundSize: themeId === 'a' ? '80px 80px' : themeId === 'c' ? '100px 100px' : '0 0',
      }} />

      {/* ===== TOP BAR ===== */}
      <div style={{
        height: 56, background: t.surface, borderBottom: `${t.borderWHeavy} solid ${t.border}`,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 16px', zIndex: 100, position: 'relative',
        transition: `background var(--theme-transition)`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div
            onClick={() => navigate('/')}
            style={{
              fontFamily: t.fontDisplay, fontSize: 22, color: t.text,
              display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer',
            }}
          >
            <span style={{ display: 'inline-flex', gap: 3 }}>
              <span style={{ width: 10, height: 10, background: DAILY_COLORS[0], borderRadius: '50%', display: 'inline-block' }} />
              <span style={{ width: 10, height: 10, background: DAILY_COLORS[1], borderRadius: '50%', display: 'inline-block' }} />
            </span>
            2colors
          </div>

          {/* Dark mode toggle + Theme switcher */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 2,
            background: t.selected,
            border: `${t.borderW} solid ${t.borderLight}`,
            borderRadius: t.radiusMd,
            padding: 3,
          }}>
            <button
              onClick={() => setDarkMode(!darkMode)}
              style={{
                width: 28, height: 28, background: darkMode ? t.darkmodeBtnBg : 'transparent',
                border: 'none', borderRadius: t.radiusSm, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 14, transition: 'all 0.25s',
              }}
              title={darkMode ? 'Light mode' : 'Dark mode'}
            >
              {darkMode ? (
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={themeId === 'd' ? '#111' : '#2D1B69'} strokeWidth="2.5" strokeLinecap="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
              ) : (
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
              )}
            </button>
            <div style={{ width: 1, height: 18, background: t.borderLight, flexShrink: 0 }} />
            {(['a', 'b', 'c', 'd'] as ThemeId[]).map((tid) => (
              <button
                key={tid}
                onClick={() => setThemeId(tid)}
                style={{
                  width: 28, height: 28,
                  background: themeId === tid ? t.accent : 'transparent',
                  color: themeId === tid ? accentTextColor : t.textMuted,
                  border: 'none', borderRadius: t.radiusSm, cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 11, fontWeight: 700, fontFamily: 'inherit',
                  transition: 'all 0.2s', letterSpacing: 0.5,
                }}
                onMouseEnter={e => {
                  if (themeId !== tid) {
                    e.currentTarget.style.background = t._selectedHover()
                    e.currentTarget.style.color = t._text()
                  }
                }}
                onMouseLeave={e => {
                  if (themeId !== tid) {
                    e.currentTarget.style.background = 'transparent'
                    e.currentTarget.style.color = t._textMuted()
                  }
                }}
                title={THEME_LABELS[tid]}
              >
                {tid.toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        {/* Center: Gallery title */}
        <div style={{ position: 'absolute', left: '50%', transform: 'translateX(-50%)', textAlign: 'center' }}>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 20, color: t.text, lineHeight: 1 }}>
            Gallery
          </div>
        </div>

        {/* Right: back to canvas */}
        <button
          onClick={() => navigate('/')}
          style={{
            background: t.selected, border: `${t.borderW} solid ${t.border}`, color: t.text,
            padding: '5px 14px', fontSize: 12, fontWeight: 600, cursor: 'pointer',
            borderRadius: t.radiusPill, fontFamily: 'inherit', transition: 'all 0.2s',
            display: 'flex', alignItems: 'center', gap: 6,
          }}
          onMouseEnter={e => { e.currentTarget.style.background = t._selectedHover(); e.currentTarget.style.transform = 'translateY(-1px)' }}
          onMouseLeave={e => { e.currentTarget.style.background = t._selected(); e.currentTarget.style.transform = 'translateY(0)' }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M15 18l-6-6 6-6"/></svg>
          Back to canvas
        </button>
      </div>

      {/* ===== MAIN CONTENT ===== */}
      <div style={{
        flex: 1, overflow: 'auto', zIndex: 1,
        padding: '0',
      }}>
        <div style={{
          maxWidth: 860, margin: '0 auto',
          padding: '24px 24px 48px',
        }}>
          {/* Tab bar */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            style={{
              display: 'flex',
              background: t.selected,
              border: `${t.borderW} solid ${t.borderLight}`,
              borderRadius: t.radiusLg,
              padding: 3,
              marginBottom: 24,
            }}
          >
            {TAB_CONFIG.map((tab) => (
              <button
                key={tab.id}
                onClick={() => handleTabChange(tab.id)}
                style={{
                  flex: 1,
                  background: activeTab === tab.id ? t.surface : 'transparent',
                  border: activeTab === tab.id ? `${t.borderW} solid ${t.border}` : '1px solid transparent',
                  color: activeTab === tab.id ? t.text : t.textMuted,
                  padding: '8px 16px',
                  fontSize: 13, fontWeight: activeTab === tab.id ? 700 : 600,
                  cursor: 'pointer', borderRadius: t.radiusMd,
                  fontFamily: 'inherit', transition: 'all 0.2s',
                  boxShadow: activeTab === tab.id ? t.btnShadow : 'none',
                }}
                onMouseEnter={e => {
                  if (activeTab !== tab.id) e.currentTarget.style.color = t._text()
                }}
                onMouseLeave={e => {
                  if (activeTab !== tab.id) e.currentTarget.style.color = t._textMuted()
                }}
              >
                {tab.label}
              </button>
            ))}
          </motion.div>

          {/* Content area */}
          <AnimatePresence mode="wait">
            <motion.div
              key={`${activeTab}-${viewMode}`}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.2 }}
            >
              {/* Grid views */}
              {currentTabHasGrid && viewMode === 'grid' ? (
                activeTab === 'wall' ? renderWallGrid() : renderFriendsGrid()
              ) : (
                <>
                  {/* View toggle for Wall/Friends in calendar mode */}
                  {currentTabHasGrid && (
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                      {renderViewToggle()}
                      <div />
                    </div>
                  )}

                  {/* Month navigation */}
                  <div style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    gap: 16, marginBottom: 20,
                  }}>
                    <button onClick={prevMonth} style={navArrowStyle(t)}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M15 18l-6-6 6-6"/></svg>
                    </button>
                    <div style={{ fontFamily: t.fontDisplay, fontSize: 18, color: t.text, fontWeight: 700, minWidth: 200, textAlign: 'center' }}>
                      {MONTH_NAMES[viewMonth - 1]} {viewYear}
                    </div>
                    <button onClick={nextMonth} style={navArrowStyle(t)}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M9 18l6-6-6-6"/></svg>
                    </button>
                  </div>

                  {/* Calendar grid */}
                  <div>
                    {/* Day headers */}
                    <div style={{
                      display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)',
                      gap: 4, marginBottom: 4,
                    }}>
                      {DAY_HEADERS.map(d => (
                        <div key={d} style={{
                          textAlign: 'center', fontSize: 10, fontWeight: 700,
                          color: t.textMuted, letterSpacing: 1,
                          textTransform: 'uppercase', padding: '6px 0',
                        }}>
                          {d}
                        </div>
                      ))}
                    </div>

                    {/* Calendar cells */}
                    <div style={{
                      display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)',
                      gap: 4,
                    }}>
                      {calendarDays.map((day, idx) => renderCalendarCell(day, idx))}
                    </div>
                  </div>

                  {renderFooter()}
                </>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  )
}

// ===== Sub-components =====

function SubmissionCard({
  submission,
  t,
  themeId,
  onClick,
  showDate,
}: {
  submission: MockSubmission
  t: ReturnType<typeof useThemeVars>
  themeId: ThemeId
  onClick: () => void
  showDate?: boolean
}) {
  return (
    <div
      onClick={onClick}
      style={{
        cursor: 'pointer',
        borderRadius: t.radiusLg,
        overflow: 'hidden',
        border: `${t.borderW} solid ${t.borderLight}`,
        background: t.surface,
        boxShadow: t.btnShadow,
        transition: 'transform 0.15s, box-shadow 0.15s',
      }}
      onMouseEnter={e => {
        e.currentTarget.style.transform = 'translateY(-3px)'
        e.currentTarget.style.boxShadow = t._cardShadow()
      }}
      onMouseLeave={e => {
        e.currentTarget.style.transform = 'translateY(0)'
        e.currentTarget.style.boxShadow = t._btnShadow()
      }}
    >
      <ArtThumbnail
        submission={submission}
        size="100%"
        style={{ aspectRatio: '1', borderRadius: 0 }}
      />
      <div style={{
        padding: '8px 10px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div>
          <div style={{ fontSize: 12, fontWeight: 700, color: t.text }}>
            {submission.artist}
          </div>
          {showDate && (
            <div style={{ fontSize: 10, color: t.textMuted, fontWeight: 500, marginTop: 1 }}>
              {new Date(submission.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </div>
          )}
        </div>
        {submission.isWinner && (
          <span style={{ fontSize: 14 }}>🏆</span>
        )}
      </div>
    </div>
  )
}

function WallCalendarBubble({
  count,
  colors,
  t,
}: {
  count: number
  colors: string[]
  t: ReturnType<typeof useThemeVars>
}) {
  // Creative mosaic-like circle showing submission count
  const size = Math.min(32, 16 + count * 3)
  const mainColor = colors[0] || '#ccc'

  return (
    <div style={{
      width: size, height: size,
      borderRadius: '50%',
      background: mainColor,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      position: 'relative',
      border: `2px solid ${t.borderLight}`,
      boxShadow: `0 2px 6px ${mainColor}40`,
    }}>
      {/* Overlay with count */}
      <span style={{
        fontSize: count > 9 ? 9 : 11,
        fontWeight: 800,
        color: '#fff',
        textShadow: '0 1px 2px rgba(0,0,0,0.4)',
        lineHeight: 1,
      }}>
        {count}
      </span>

      {/* Secondary color accent */}
      {colors[1] && count > 1 && (
        <div style={{
          position: 'absolute',
          bottom: -2, right: -2,
          width: 10, height: 10,
          borderRadius: '50%',
          background: colors[1],
          border: `1.5px solid ${t.surface}`,
        }} />
      )}
    </div>
  )
}

function EmptyState({ message, t }: { message: string; t: ReturnType<typeof useThemeVars> }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      style={{
        textAlign: 'center', padding: '60px 20px',
        color: t.textMuted,
      }}
    >
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"
        style={{ margin: '0 auto 12px', opacity: 0.4 }}>
        <rect x="3" y="3" width="18" height="18" rx="2"/>
        <path d="M3 9h18"/>
        <path d="M9 21V9"/>
      </svg>
      <div style={{ fontSize: 14, fontWeight: 600 }}>{message}</div>
    </motion.div>
  )
}

function navArrowStyle(t: ReturnType<typeof useThemeVars>): React.CSSProperties {
  return {
    width: 32, height: 32,
    background: t.surface,
    border: `${t.borderW} solid ${t.borderLight}`,
    borderRadius: t.radiusMd,
    cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    color: t.text, fontFamily: 'inherit',
    transition: 'all 0.15s',
  }
}
