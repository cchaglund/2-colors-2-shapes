import { useState, useMemo } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { motion } from 'motion/react'
import {
  type ThemeId,
  THEME_LABELS,
  DAILY_COLORS,
  useThemeVars,
  getAccentTextColor,
} from './shared'
import ArtThumbnail from './ArtThumbnail'
import { getSubmissionById } from './mockData'

export default function SubmissionDetail() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()

  const [darkMode, setDarkMode] = useState(() => {
    return document.documentElement.getAttribute('data-mode') === 'dark'
  })
  const [themeId, setThemeId] = useState<ThemeId>(() => {
    return (document.documentElement.getAttribute('data-theme') as ThemeId) || 'a'
  })
  const t = useThemeVars(darkMode, themeId)
  const accentTextColor = getAccentTextColor(themeId)

  const [liked, setLiked] = useState(false)
  const [copied, setCopied] = useState(false)

  const submission = useMemo(() => {
    if (!id) return null
    return getSubmissionById(id)
  }, [id])

  if (!submission) {
    return (
      <div style={{
        width: '100vw', height: '100vh', background: t.bg,
        fontFamily: t.fontBody, color: t.text,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 48, marginBottom: 12, opacity: 0.3 }}>?</div>
          <div style={{ fontSize: 16, fontWeight: 600, color: t.textMuted }}>Submission not found</div>
          <button
            onClick={() => navigate('/gallery')}
            style={{
              marginTop: 16,
              background: t.accent, border: `${t.borderW} solid ${t.border}`,
              color: accentTextColor, padding: '8px 20px',
              fontSize: 13, fontWeight: 700, cursor: 'pointer',
              borderRadius: t.radiusPill, fontFamily: 'inherit',
            }}
          >
            Back to Gallery
          </button>
        </div>
      </div>
    )
  }

  const dateObj = new Date(submission.date)
  const formattedDate = dateObj.toLocaleDateString('en-US', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  })

  const handleCopyLink = () => {
    navigator.clipboard.writeText(`https://2colors.app/gallery/${submission.id}`)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const rankLabel = submission.rank === 1 ? 'Winner of the day!' :
    submission.rank === 2 ? 'Runner up' :
    submission.rank === 3 ? 'Third place' :
    `Placed ${submission.rank}${submission.rank === 21 || submission.rank === 31 ? 'st' : submission.rank === 22 ? 'nd' : submission.rank === 23 ? 'rd' : 'th'}`

  const rankEmoji = submission.rank === 1 ? '🏆' :
    submission.rank === 2 ? '🥈' :
    submission.rank === 3 ? '🥉' : '🎨'

  return (
    <div style={{
      width: '100vw', height: '100vh', background: t.bg,
      fontFamily: t.fontBody, color: t.text,
      display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative',
      transition: `background var(--theme-transition), color var(--theme-transition)`,
    }}>
      <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@300;400;500;600;700&family=Lilita+One&family=DM+Sans:wght@300;400;500;600;700&family=Nunito:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet" />

      {/* Background pattern */}
      <div style={{
        position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0,
        opacity: t.patternOpacity,
        backgroundImage: themeId === 'a'
          ? `radial-gradient(circle at 20px 20px, #FF3366 2px, transparent 2px), radial-gradient(circle at 60px 60px, #33CCFF 1.5px, transparent 1.5px)`
          : themeId === 'c'
            ? `radial-gradient(circle at 30px 30px, rgba(157, 196, 176, 0.18) 3px, transparent 3px), radial-gradient(circle at 70px 70px, rgba(224, 122, 95, 0.1) 4px, transparent 4px)`
            : 'none',
        backgroundSize: themeId === 'a' ? '80px 80px' : themeId === 'c' ? '100px 100px' : '0 0',
      }} />

      {/* ===== TOP BAR ===== */}
      <div style={{
        height: 56, background: t.surface, borderBottom: `${t.borderWHeavy} solid ${t.border}`,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 16px', zIndex: 100, position: 'relative',
        transition: `background var(--theme-transition)`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div
            onClick={() => navigate('/')}
            style={{
              fontFamily: t.fontDisplay, fontSize: 22, color: t.text,
              display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer',
            }}
          >
            <span style={{ display: 'inline-flex', gap: 3 }}>
              <span style={{ width: 10, height: 10, background: DAILY_COLORS[0], borderRadius: '50%', display: 'inline-block' }} />
              <span style={{ width: 10, height: 10, background: DAILY_COLORS[1], borderRadius: '50%', display: 'inline-block' }} />
            </span>
            2colors
          </div>

          {/* Dark mode + Theme switcher */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 2,
            background: t.selected,
            border: `${t.borderW} solid ${t.borderLight}`,
            borderRadius: t.radiusMd, padding: 3,
          }}>
            <button
              onClick={() => setDarkMode(!darkMode)}
              style={{
                width: 28, height: 28, background: darkMode ? t.darkmodeBtnBg : 'transparent',
                border: 'none', borderRadius: t.radiusSm, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 14, transition: 'all 0.25s',
              }}
              title={darkMode ? 'Light mode' : 'Dark mode'}
            >
              {darkMode ? (
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={themeId === 'd' ? '#111' : '#2D1B69'} strokeWidth="2.5" strokeLinecap="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
              ) : (
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
              )}
            </button>
            <div style={{ width: 1, height: 18, background: t.borderLight, flexShrink: 0 }} />
            {(['a', 'b', 'c', 'd'] as ThemeId[]).map((tid) => (
              <button
                key={tid}
                onClick={() => setThemeId(tid)}
                style={{
                  width: 28, height: 28,
                  background: themeId === tid ? t.accent : 'transparent',
                  color: themeId === tid ? accentTextColor : t.textMuted,
                  border: 'none', borderRadius: t.radiusSm, cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 11, fontWeight: 700, fontFamily: 'inherit',
                  transition: 'all 0.2s', letterSpacing: 0.5,
                }}
                onMouseEnter={e => {
                  if (themeId !== tid) {
                    e.currentTarget.style.background = t._selectedHover()
                    e.currentTarget.style.color = t._text()
                  }
                }}
                onMouseLeave={e => {
                  if (themeId !== tid) {
                    e.currentTarget.style.background = 'transparent'
                    e.currentTarget.style.color = t._textMuted()
                  }
                }}
                title={THEME_LABELS[tid]}
              >
                {tid.toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        {/* Center */}
        <div style={{ position: 'absolute', left: '50%', transform: 'translateX(-50%)', textAlign: 'center' }}>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 20, color: t.text, lineHeight: 1 }}>
            Submission
          </div>
        </div>

        {/* Right: navigation */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button
            onClick={() => navigate('/gallery')}
            style={{
              background: t.selected, border: `${t.borderW} solid ${t.border}`, color: t.text,
              padding: '5px 14px', fontSize: 12, fontWeight: 600, cursor: 'pointer',
              borderRadius: t.radiusPill, fontFamily: 'inherit', transition: 'all 0.2s',
              display: 'flex', alignItems: 'center', gap: 6,
            }}
            onMouseEnter={e => { e.currentTarget.style.background = t._selectedHover(); e.currentTarget.style.transform = 'translateY(-1px)' }}
            onMouseLeave={e => { e.currentTarget.style.background = t._selected(); e.currentTarget.style.transform = 'translateY(0)' }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M15 18l-6-6 6-6"/></svg>
            Gallery
          </button>
        </div>
      </div>

      {/* ===== CONTENT ===== */}
      <div style={{ flex: 1, overflow: 'auto', zIndex: 1 }}>
        <div style={{
          maxWidth: 940, margin: '0 auto',
          padding: '32px 24px 64px',
        }}>
          {/* Title area */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div style={{
              fontFamily: t.fontDisplay, fontSize: 26, color: t.text,
              marginBottom: 4, lineHeight: 1.2,
            }}>
              {formattedDate}
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 28 }}>
              <span style={{ fontSize: 13, fontWeight: 700, color: t.text }}>
                @{submission.artist}
              </span>
              <span style={{ fontSize: 12, color: t.textMuted }}>·</span>
              <span style={{ fontSize: 12, color: t.textMuted, fontWeight: 500 }}>
                Submission
              </span>
              {submission.isFriend && (
                <span style={{
                  fontSize: 10, fontWeight: 700,
                  background: t.selected, border: `1px solid ${t.borderLight}`,
                  borderRadius: t.radiusPill, padding: '2px 10px',
                  color: t.textMuted,
                }}>
                  Following
                </span>
              )}
            </div>
          </motion.div>

          {/* Main layout: Art + sidebar */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 280px',
            gap: 24,
            alignItems: 'start',
          }}>
            {/* Left: Artwork */}
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: 0.1 }}
            >
              <div style={{
                borderRadius: t.radiusLg,
                border: `${t.borderWHeavy} solid ${t.border}`,
                overflow: 'hidden',
                boxShadow: t.cardShadow,
                background: submission.bgColor,
                aspectRatio: '1',
              }}>
                <ArtThumbnail
                  submission={submission}
                  size="100%"
                  style={{ aspectRatio: '1' }}
                />
              </div>

              {/* Like button below artwork */}
              <div style={{ marginTop: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
                <motion.button
                  onClick={() => setLiked(!liked)}
                  whileTap={{ scale: 0.9 }}
                  style={{
                    background: 'none', border: `${t.borderW} solid ${t.borderLight}`,
                    borderRadius: t.radiusMd, padding: '8px 14px',
                    cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
                    fontSize: 13, fontWeight: 600, color: liked ? t.accent : t.textMuted,
                    fontFamily: 'inherit', transition: 'all 0.15s',
                  }}
                >
                  <motion.svg
                    width="18" height="18" viewBox="0 0 24 24"
                    fill={liked ? 'currentColor' : 'none'}
                    stroke="currentColor" strokeWidth="2" strokeLinecap="round"
                    animate={liked ? { scale: [1, 1.3, 1] } : {}}
                    transition={{ duration: 0.3 }}
                  >
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                  </motion.svg>
                  {liked ? 'Liked' : 'Like'}
                </motion.button>
              </div>
            </motion.div>

            {/* Right: Sidebar cards */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {/* Inspiration + Colors + Shapes card */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.15 }}
                style={{
                  background: t.surface,
                  border: `${t.borderW} solid ${t.borderLight}`,
                  borderRadius: t.radiusLg,
                  padding: 20,
                  boxShadow: t.btnShadow,
                }}
              >
                {/* Inspiration word */}
                <div style={{ marginBottom: 16 }}>
                  <div style={{
                    fontSize: 9, fontWeight: 700, letterSpacing: 1.5,
                    textTransform: 'uppercase', color: t.textMuted, marginBottom: 4,
                  }}>
                    Inspiration
                  </div>
                  <div style={{ fontFamily: t.fontDisplay, fontSize: 20, color: t.text }}>
                    "{submission.word}"
                  </div>
                </div>

                {/* Colors */}
                <div style={{ marginBottom: 16 }}>
                  <div style={{
                    fontSize: 9, fontWeight: 700, letterSpacing: 1.5,
                    textTransform: 'uppercase', color: t.textMuted, marginBottom: 6,
                  }}>
                    Colors
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    {submission.colors.map((color, i) => (
                      <div key={i} style={{
                        width: 32, height: 32,
                        background: color,
                        borderRadius: t.radiusSm,
                        border: `${t.borderW} solid ${t.borderLight}`,
                      }} />
                    ))}
                  </div>
                </div>

                {/* Shapes */}
                <div>
                  <div style={{
                    fontSize: 9, fontWeight: 700, letterSpacing: 1.5,
                    textTransform: 'uppercase', color: t.textMuted, marginBottom: 6,
                  }}>
                    Shapes
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    {['circle', 'square'].map(type => {
                      const count = submission.shapes.filter(s => s.type === type).length
                      if (count === 0) return null
                      return (
                        <div key={type} style={{
                          display: 'flex', alignItems: 'center', gap: 5,
                          background: t.selected,
                          borderRadius: t.radiusSm,
                          padding: '6px 10px',
                        }}>
                          <div style={{
                            width: 16, height: 16,
                            background: t.text,
                            borderRadius: type === 'circle' ? '50%' : '2px',
                            opacity: 0.7,
                          }} />
                          <span style={{ fontSize: 11, fontWeight: 700, color: t.text }}>{count}</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </motion.div>

              {/* Ranking card */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.25 }}
                style={{
                  background: t.surface,
                  border: `${t.borderW} solid ${t.borderLight}`,
                  borderRadius: t.radiusLg,
                  padding: 20,
                  boxShadow: t.btnShadow,
                }}
              >
                <div style={{
                  fontSize: 13, fontWeight: 700, color: t.text, marginBottom: 10,
                }}>
                  Ranking
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
                  <span style={{ fontSize: 24 }}>{rankEmoji}</span>
                  <span style={{ fontSize: 18, fontWeight: 800, color: t.text }}>
                    #{submission.rank}
                  </span>
                  <span style={{ fontSize: 13, color: t.textMuted, fontWeight: 500 }}>
                    / {submission.totalSubmissions}
                  </span>
                </div>
                <div style={{ fontSize: 12, color: submission.rank === 1 ? t.accent : t.textMuted, fontWeight: 600 }}>
                  {rankLabel}
                </div>
              </motion.div>

              {/* Stats card */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.35 }}
                style={{
                  background: t.surface,
                  border: `${t.borderW} solid ${t.borderLight}`,
                  borderRadius: t.radiusLg,
                  padding: 20,
                  boxShadow: t.btnShadow,
                }}
              >
                <div style={{
                  fontSize: 13, fontWeight: 700, color: t.text, marginBottom: 10,
                }}>
                  Submission Stats
                </div>
                {[
                  ['Shapes used', String(submission.shapeCount)],
                  ['Submitted', new Date(submission.submittedAt).toLocaleDateString('en-US', { month: 'numeric', day: 'numeric', year: 'numeric' })],
                ].map(([label, value]) => (
                  <div key={label} style={{
                    display: 'flex', justifyContent: 'space-between',
                    alignItems: 'center', padding: '5px 0',
                  }}>
                    <span style={{ fontSize: 12, color: t.textMuted, fontWeight: 500 }}>{label}</span>
                    <span style={{ fontSize: 12, fontWeight: 700, color: t.text }}>{value}</span>
                  </div>
                ))}
              </motion.div>

              {/* Export & Share card */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.45 }}
                style={{
                  background: t.surface,
                  border: `${t.borderW} solid ${t.borderLight}`,
                  borderRadius: t.radiusLg,
                  padding: 20,
                  boxShadow: t.btnShadow,
                }}
              >
                <div style={{
                  fontSize: 13, fontWeight: 700, color: t.text, marginBottom: 12,
                }}>
                  Export & Share
                </div>
                <button
                  onClick={handleCopyLink}
                  style={{
                    width: '100%',
                    background: t.selected,
                    border: `${t.borderW} solid ${t.borderLight}`,
                    borderRadius: t.radiusMd,
                    padding: '10px 0',
                    cursor: 'pointer',
                    fontSize: 12, fontWeight: 600, color: t.text,
                    fontFamily: 'inherit',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                    transition: 'all 0.15s',
                  }}
                  onMouseEnter={e => {
                    e.currentTarget.style.background = t._selectedHover()
                    e.currentTarget.style.borderColor = t._border()
                  }}
                  onMouseLeave={e => {
                    e.currentTarget.style.background = t._selected()
                    e.currentTarget.style.borderColor = t._borderLight()
                  }}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
                    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
                  </svg>
                  {copied ? 'Copied!' : 'Copy Link'}
                </button>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
