/* eslint-disable react-hooks/immutability */
import { useState, useRef, useCallback, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'motion/react'

const DAILY_COLORS = ['#FF3366', '#33CCFF', '#FFCC00'] as const
const DAILY_SHAPES = ['circle', 'square'] as const
const DAILY_WORD = 'Ephemeral'

type ThemeId = 'a' | 'b' | 'c' | 'd'

const THEME_LABELS: Record<ThemeId, string> = {
  a: 'Pop Art',
  b: 'Swiss',
  c: 'Cloud',
  d: 'Brutal',
}

type Shape = {
  id: string
  type: 'circle' | 'square'
  color: string
  x: number
  y: number
  size: number
  rotation: number
  groupId?: string
  visible?: boolean
}

type Group = {
  id: string
  name: string
  collapsed: boolean
}

function useThemeVars(darkMode: boolean, themeId: ThemeId) {
  // Apply data attributes to document root so CSS variables activate
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', themeId)
    document.documentElement.setAttribute('data-mode', darkMode ? 'dark' : 'light')
  }, [darkMode, themeId])

  // Read CSS variables. We use var() directly in inline styles,
  // but for the `t` object (used in JS hover handlers etc.) we
  // read computed values once per render.
  const read = (name: string) => {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim()
  }

  // Provide both the var() reference (for inline styles) and
  // the resolved value (for imperative JS style manipulation)
  return {
    bg:             'var(--bg)',
    surface:        'var(--surface)',
    surfaceHover:   'var(--surface-hover)',
    border:         'var(--border)',
    borderLight:    'var(--border-light)',
    text:           'var(--text)',
    textMuted:      'var(--text-muted)',
    accent:         'var(--accent)',
    accentText:     'var(--accent-text)',
    selected:       'var(--selected)',
    selectedHover:  'var(--selected-hover)',
    patternOpacity: 'var(--pattern-opacity)',
    cardShadow:     'var(--card-shadow)',
    btnShadow:      'var(--btn-shadow)',
    modalShadow:    'var(--modal-shadow)',
    overlay:        'var(--overlay)',
    darkmodeBtnBg:  'var(--darkmode-btn-bg)',
    fontBody:       'var(--font-body)',
    fontDisplay:    'var(--font-display)',
    radiusSm:       'var(--radius-sm)',
    radiusMd:       'var(--radius-md)',
    radiusLg:       'var(--radius-lg)',
    radiusXl:       'var(--radius-xl)',
    radius2xl:      'var(--radius-2xl)',
    radiusPill:     'var(--radius-pill)',
    borderW:        'var(--border-w)',
    borderWHeavy:   'var(--border-w-heavy)',
    patternImage:   'var(--pattern-image)',
    patternSize:    'var(--pattern-size)',
    // Resolved values for JS manipulation (hover handlers etc.)
    _surface:       () => read('--surface'),
    _surfaceHover:  () => read('--surface-hover'),
    _border:        () => read('--border'),
    _borderLight:   () => read('--border-light'),
    _text:          () => read('--text'),
    _textMuted:     () => read('--text-muted'),
    _accent:        () => read('--accent'),
    _selected:      () => read('--selected'),
    _selectedHover: () => read('--selected-hover'),
    _btnShadow:     () => read('--btn-shadow'),
    _cardShadow:    () => read('--card-shadow'),
  }
}

export default function Design2() {
  const navigate = useNavigate()
  const [shapes, setShapes] = useState<Shape[]>([])
  const [groups, setGroups] = useState<Group[]>([])
  const [bgColor, setBgColor] = useState('#FFF5F0')
  const [toolMode, setToolMode] = useState<'select' | 'circle' | 'square'>('select')
  const [selectedColor, setSelectedColor] = useState<typeof DAILY_COLORS[number]>(DAILY_COLORS[0])
  const [showLayers, setShowLayers] = useState(false)
  const [showTools, setShowTools] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [showUserMenu, setShowUserMenu] = useState(false)
  const [friendsTab, setFriendsTab] = useState<'following' | 'followers'>('following')
  const [addFriendValue, setAddFriendValue] = useState('')
  const [showInfo, setShowInfo] = useState(false)
  const [zoom, setZoom] = useState(1)
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const [isPanning, setIsPanning] = useState(false)
  const panStart = useRef({ x: 0, y: 0, panX: 0, panY: 0 })
  const [history, setHistory] = useState<Shape[][]>([])
  const [redoStack, setRedoStack] = useState<Shape[][]>([])
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [hoveredColor, setHoveredColor] = useState<string | null>(null)
  const [hoveredLayerId, setHoveredLayerId] = useState<string | null>(null)
  const justDragged = useRef(false)
  const [previewShape, setPreviewShape] = useState<Shape | null>(null)
  const previewShapeRef = useRef<Shape | null>(null)
  const stampDragRef = useRef<{ startClientX: number; startClientY: number } | null>(null)
  const ghostRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLDivElement>(null)
  const [darkMode, setDarkMode] = useState(false)
  const [themeId, setThemeId] = useState<ThemeId>('a')

  const t = useThemeVars(darkMode, themeId)
  const userMenuRef = useRef<HTMLDivElement>(null)

  // Mock user data
  const MOCK_USER = { name: 'Zoey', initial: 'Z' }
  const MOCK_FOLLOWING = [
    { name: 'Mika', initial: 'M', status: 'online' as const },
    { name: 'Juno', initial: 'J', status: 'offline' as const },
    { name: 'Ravi', initial: 'R', status: 'online' as const },
  ]
  const MOCK_FOLLOWERS = [
    { name: 'Mika', initial: 'M', status: 'online' as const },
    { name: 'Sage', initial: 'S', status: 'offline' as const },
    { name: 'Lux', initial: 'L', status: 'online' as const },
    { name: 'Ravi', initial: 'R', status: 'online' as const },
  ]

  // Close user menu on outside click
  useEffect(() => {
    if (!showUserMenu) return
    const handler = (e: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setShowUserMenu(false)
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [showUserMenu])

  // Ghost cursor tracking (direct DOM updates, no re-renders)
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ghostRef.current) {
        ghostRef.current.style.left = `${e.clientX}px`
        ghostRef.current.style.top = `${e.clientY}px`
      }
    }
    window.addEventListener('mousemove', handler)
    return () => window.removeEventListener('mousemove', handler)
  }, [])

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return
      switch (e.key) {
        case 'Escape':
        case 'v':
        case 'V':
          setToolMode('select')
          break
        case 'z':
        case 'Z':
          if (!e.metaKey && !e.ctrlKey) {
            if (e.shiftKey) redo(); else undo()
          }
          break
        case 'Backspace':
        case 'Delete':
          if (selectedIds.size > 0) {
            setHistory(prev => [...prev, shapes])
            setRedoStack([])
            setShapes(prev => prev.filter(s => !selectedIds.has(s.id)))
            setSelectedIds(new Set())
          }
          break
        case 'ArrowUp':
          if (selectedIds.size > 0) { e.preventDefault(); setShapes(prev => prev.map(s => selectedIds.has(s.id) ? { ...s, y: s.y - (e.shiftKey ? 10 : 1) } : s)) }
          break
        case 'ArrowDown':
          if (selectedIds.size > 0) { e.preventDefault(); setShapes(prev => prev.map(s => selectedIds.has(s.id) ? { ...s, y: s.y + (e.shiftKey ? 10 : 1) } : s)) }
          break
        case 'ArrowLeft':
          if (selectedIds.size > 0) { e.preventDefault(); setShapes(prev => prev.map(s => selectedIds.has(s.id) ? { ...s, x: s.x - (e.shiftKey ? 10 : 1) } : s)) }
          break
        case 'ArrowRight':
          if (selectedIds.size > 0) { e.preventDefault(); setShapes(prev => prev.map(s => selectedIds.has(s.id) ? { ...s, x: s.x + (e.shiftKey ? 10 : 1) } : s)) }
          break
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  })

  const selectedShapeId = selectedIds.size === 1 ? [...selectedIds][0] : null

  // Stamp mode: mousedown on canvas starts placing a shape
  const handleStampDown = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (toolMode === 'select') return
    if (e.altKey || e.metaKey) return

    const rect = e.currentTarget.getBoundingClientRect()
    const x = (e.clientX - rect.left) / zoom
    const y = (e.clientY - rect.top) / zoom

    const defaultSize = 60
    const newShape: Shape = {
      id: `s-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      type: toolMode,
      color: selectedColor,
      x, y,
      size: defaultSize,
      rotation: 0,
    }

    previewShapeRef.current = newShape
    setPreviewShape(newShape)
    stampDragRef.current = { startClientX: e.clientX, startClientY: e.clientY }

    const currentZoom = zoom
    const currentShapes = shapes

    const handleMove = (ev: MouseEvent) => {
      if (!stampDragRef.current || !previewShapeRef.current) return
      const dx = (ev.clientX - stampDragRef.current.startClientX) / currentZoom
      const dy = (ev.clientY - stampDragRef.current.startClientY) / currentZoom
      const dist = Math.sqrt(dx * dx + dy * dy)
      if (dist > 5) {
        const updated = { ...previewShapeRef.current, size: Math.max(20, dist * 2) }
        previewShapeRef.current = updated
        setPreviewShape(updated)
      }
    }

    const handleUp = () => {
      const finalShape = previewShapeRef.current
      if (finalShape) {
        setHistory(h => [...h, currentShapes])
        setRedoStack([])
        setShapes(s => [...s, finalShape])
      }
      previewShapeRef.current = null
      setPreviewShape(null)
      stampDragRef.current = null
      window.removeEventListener('mousemove', handleMove)
      window.removeEventListener('mouseup', handleUp)
    }

    window.addEventListener('mousemove', handleMove)
    window.addEventListener('mouseup', handleUp)
  }, [toolMode, selectedColor, zoom, shapes])

  // Layer panel select: also switches to select mode
  const selectFromLayer = (id: string, e?: React.MouseEvent) => {
    setToolMode('select')
    selectShape(id, e)
  }

  // Select mode: click on empty canvas deselects all
  const handleCanvasClick = useCallback(() => {
    if (isPanning) return
    if (justDragged.current) { justDragged.current = false; return }
    setSelectedIds(new Set())
  }, [isPanning])

  const selectShape = (id: string, e?: React.MouseEvent) => {
    if (e?.shiftKey) {
      setSelectedIds(prev => {
        const next = new Set(prev)
        if (next.has(id)) next.delete(id); else next.add(id)
        return next
      })
    } else {
      setSelectedIds(new Set([id]))
    }
  }

  const undo = () => {
    if (history.length === 0) return
    setRedoStack(prev => [...prev, shapes])
    setShapes(history[history.length - 1])
    setHistory(prev => prev.slice(0, -1))
  }

  const redo = () => {
    if (redoStack.length === 0) return
    setHistory(prev => [...prev, shapes])
    setShapes(redoStack[redoStack.length - 1])
    setRedoStack(prev => prev.slice(0, -1))
  }

  const deleteShape = (id: string) => {
    setHistory(prev => [...prev, shapes])
    setRedoStack([])
    setShapes(prev => prev.filter(s => s.id !== id))
    setSelectedIds(prev => { const n = new Set(prev); n.delete(id); return n })
  }

  const moveLayer = (id: string, direction: 'up' | 'down') => {
    setShapes(prev => {
      const idx = prev.findIndex(s => s.id === id)
      if (idx === -1) return prev
      const next = [...prev]
      const swapIdx = direction === 'up' ? idx + 1 : idx - 1
      if (swapIdx < 0 || swapIdx >= next.length) return prev
      ;[next[idx], next[swapIdx]] = [next[swapIdx], next[idx]]
      return next
    })
  }

  const duplicateShape = (id: string) => {
    const s = shapes.find(s => s.id === id)
    if (!s) return
    setHistory(prev => [...prev, shapes])
    setRedoStack([])
    const newId = `s-${Date.now()}`
    setShapes(prev => [...prev, { ...s, id: newId, x: s.x + 20, y: s.y + 20, groupId: undefined }])
  }

  const toggleVisibility = (id: string) => {
    setShapes(prev => prev.map(s => s.id === id ? { ...s, visible: s.visible === false ? true : false } : s))
  }

  const groupSelected = () => {
    if (selectedIds.size < 2) return
    const gId = `g-${Date.now()}`
    setGroups(prev => [...prev, { id: gId, name: `Group ${prev.length + 1}`, collapsed: false }])
    setShapes(prev => prev.map(s => selectedIds.has(s.id) ? { ...s, groupId: gId } : s))
  }

  const ungroupGroup = (gId: string) => {
    setShapes(prev => prev.map(s => s.groupId === gId ? { ...s, groupId: undefined } : s))
    setGroups(prev => prev.filter(g => g.id !== gId))
  }

  const toggleGroupCollapse = (gId: string) => {
    setGroups(prev => prev.map(g => g.id === gId ? { ...g, collapsed: !g.collapsed } : g))
  }

  const updateShape = (id: string, updates: Partial<Shape>) => {
    setHistory(prev => [...prev, shapes])
    setRedoStack([])
    setShapes(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s))
  }

  const handleCanvasMouseDown = (e: React.MouseEvent) => {
    if (e.altKey || e.metaKey) {
      setIsPanning(true)
      panStart.current = { x: e.clientX, y: e.clientY, panX: pan.x, panY: pan.y }
      e.preventDefault()
    }
  }
  const handleCanvasMouseMove = (e: React.MouseEvent) => {
    if (isPanning) setPan({ x: panStart.current.panX + (e.clientX - panStart.current.x), y: panStart.current.panY + (e.clientY - panStart.current.y) })
  }
  const handleCanvasMouseUp = () => setIsPanning(false)
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault()
    setZoom(z => Math.max(0.25, Math.min(4, z * (e.deltaY > 0 ? 0.9 : 1.1))))
  }

  const toolBtnBase: React.CSSProperties = {
    width: 40, height: 40,
    background: t.surface, border: `${t.borderW} solid ${t.borderLight}`,
    borderRadius: t.radiusMd, cursor: 'pointer',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: 18, color: t.text, fontFamily: 'inherit', transition: 'all 0.15s', flexShrink: 0,
  }
  const toolBtnHover = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.currentTarget.style.background = t._selected()
    e.currentTarget.style.borderColor = t._border()
    e.currentTarget.style.boxShadow = t._btnShadow()
  }
  const toolBtnLeave = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.currentTarget.style.background = t._surface()
    e.currentTarget.style.borderColor = t._borderLight()
    e.currentTarget.style.boxShadow = 'none'
  }

  // Build layer tree: ungrouped shapes + groups with their children
  const ungroupedShapes = shapes.filter(s => !s.groupId)
  const groupedShapes = (gId: string) => shapes.filter(s => s.groupId === gId)

  // Accent color for theme D in dark mode needs special text treatment
  const accentTextColor = themeId === 'd' ? (darkMode ? '#111111' : '#111111') : '#fff'

  return (
    <div style={{
      width: '100vw', height: '100vh', background: t.bg,
      fontFamily: t.fontBody,
      color: t.text,
      display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative',
      transition: `background var(--theme-transition), color var(--theme-transition)`,
    }}>
      <link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@300;400;500;600;700&family=Lilita+One&family=DM+Sans:wght@300;400;500;600;700&family=Nunito:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet" />

      {/* Background pattern */}
      <div style={{
        position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0,
        opacity: t.patternOpacity,
        backgroundImage: themeId === 'a'
          ? `radial-gradient(circle at 20px 20px, #FF3366 2px, transparent 2px), radial-gradient(circle at 60px 60px, #33CCFF 1.5px, transparent 1.5px)`
          : themeId === 'c'
            ? `radial-gradient(circle at 30px 30px, rgba(157, 196, 176, 0.18) 3px, transparent 3px), radial-gradient(circle at 70px 70px, rgba(224, 122, 95, 0.1) 4px, transparent 4px)`
            : 'none',
        backgroundSize: themeId === 'a' ? '80px 80px' : themeId === 'c' ? '100px 100px' : '0 0',
      }} />

      {/* ===== TOP BAR ===== */}
      <div style={{
        height: 56, background: t.surface, borderBottom: `${t.borderWHeavy} solid ${t.border}`,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 16px', zIndex: 100, position: 'relative',
        transition: `background var(--theme-transition)`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            fontFamily: t.fontDisplay, fontSize: 22, color: t.text,
            display: 'flex', alignItems: 'center', gap: 6,
          }}>
            <span style={{ display: 'inline-flex', gap: 3 }}>
              <span style={{ width: 10, height: 10, background: DAILY_COLORS[0], borderRadius: '50%', display: 'inline-block' }} />
              <span style={{ width: 10, height: 10, background: DAILY_COLORS[1], borderRadius: '50%', display: 'inline-block' }} />
            </span>
            2colors
          </div>

          {/* Dark mode toggle + Theme switcher group */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 2,
            background: t.selected,
            border: `${t.borderW} solid ${t.borderLight}`,
            borderRadius: t.radiusMd,
            padding: 3,
          }}>
            {/* Dark mode toggle */}
            <button
              onClick={() => setDarkMode(!darkMode)}
              style={{
                width: 28, height: 28, background: darkMode ? t.darkmodeBtnBg : 'transparent',
                border: 'none', borderRadius: t.radiusSm, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 14, transition: 'all 0.25s',
              }}
              title={darkMode ? 'Light mode' : 'Dark mode'}
            >
              {darkMode ? (
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={themeId === 'd' ? '#111' : '#2D1B69'} strokeWidth="2.5" strokeLinecap="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
              ) : (
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
              )}
            </button>

            <div style={{ width: 1, height: 18, background: t.borderLight, flexShrink: 0 }} />

            {/* Theme buttons */}
            {(['a', 'b', 'c', 'd'] as ThemeId[]).map((tid) => (
              <button
                key={tid}
                onClick={() => setThemeId(tid)}
                style={{
                  width: 28, height: 28,
                  background: themeId === tid ? t.accent : 'transparent',
                  color: themeId === tid ? accentTextColor : t.textMuted,
                  border: 'none',
                  borderRadius: t.radiusSm,
                  cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 11, fontWeight: 700, fontFamily: 'inherit',
                  transition: 'all 0.2s',
                  letterSpacing: 0.5,
                }}
                onMouseEnter={e => {
                  if (themeId !== tid) {
                    e.currentTarget.style.background = t._selectedHover()
                    e.currentTarget.style.color = t._text()
                  }
                }}
                onMouseLeave={e => {
                  if (themeId !== tid) {
                    e.currentTarget.style.background = 'transparent'
                    e.currentTarget.style.color = t._textMuted()
                  }
                }}
                title={THEME_LABELS[tid]}
              >
                {tid.toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        {/* Center: inspiration word */}
        <div style={{ position: 'absolute', left: '50%', transform: 'translateX(-50%)', textAlign: 'center' }}>
          <div style={{ fontSize: 10, fontWeight: 600, color: t.accentText, letterSpacing: 2, textTransform: 'uppercase' }}>
            Today's Inspiration
          </div>
          <div style={{ fontFamily: t.fontDisplay, fontSize: 20, color: t.text, lineHeight: 1, marginTop: 1 }}>
            {DAILY_WORD}
          </div>
        </div>

        {/* Right: actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button
            onClick={() => { setShapes([]); setGroups([]); setHistory([]); setRedoStack([]); setBgColor('#FFF5F0'); setSelectedIds(new Set()) }}
            style={{
              background: t.surface, border: `${t.borderW} solid ${t.border}`, color: t.text,
              padding: '5px 14px', fontSize: 12, fontWeight: 600, cursor: 'pointer',
              borderRadius: t.radiusPill, fontFamily: 'inherit', transition: 'all 0.2s', boxShadow: t.btnShadow,
            }}
            onMouseEnter={e => { e.currentTarget.style.transform = 'translate(1px, 1px)'; e.currentTarget.style.boxShadow = t._btnShadow().replace(/[24]px/g, m => `${Math.max(1, parseInt(m) - 1)}px`) }}
            onMouseLeave={e => { e.currentTarget.style.transform = 'translate(0, 0)'; e.currentTarget.style.boxShadow = t._btnShadow() }}
          >Reset</button>
          <button style={{
            background: t.accent, border: `${t.borderW} solid ${t.border}`, color: accentTextColor,
            padding: '5px 16px', fontSize: 12, fontWeight: 700, cursor: 'pointer',
            borderRadius: t.radiusPill, fontFamily: 'inherit', transition: 'all 0.2s', boxShadow: t.btnShadow,
          }}
            onMouseEnter={e => { e.currentTarget.style.transform = 'translate(1px, 1px)'; e.currentTarget.style.boxShadow = t._btnShadow().replace(/[24]px/g, m => `${Math.max(1, parseInt(m) - 1)}px`) }}
            onMouseLeave={e => { e.currentTarget.style.transform = 'translate(0, 0)'; e.currentTarget.style.boxShadow = t._btnShadow() }}
          >Submit!</button>

          <div style={{ width: 1, height: 24, background: t.borderLight, margin: '0 4px' }} />

          <button onClick={() => navigate('/gallery')} style={{
            background: t.selected, border: `${t.borderW} solid ${t.border}`, color: t.text,
            padding: '5px 14px', fontSize: 12, fontWeight: 600, cursor: 'pointer',
            borderRadius: t.radiusPill, fontFamily: 'inherit', transition: 'all 0.2s',
          }}
            onMouseEnter={e => { e.currentTarget.style.background = t._selectedHover(); e.currentTarget.style.transform = 'translateY(-1px)' }}
            onMouseLeave={e => { e.currentTarget.style.background = t._selected(); e.currentTarget.style.transform = 'translateY(0)' }}
          >Gallery</button>
          {!isLoggedIn ? (
            <button onClick={() => setIsLoggedIn(true)} style={{
              background: t.border, border: `${t.borderW} solid ${t.border}`, color: darkMode ? t.text : '#fff',
              padding: '5px 14px', fontSize: 12, fontWeight: 600, cursor: 'pointer',
              borderRadius: t.radiusPill, fontFamily: 'inherit', transition: 'all 0.2s',
            }}
              onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-1px)'}
              onMouseLeave={e => e.currentTarget.style.transform = 'translateY(0)'}
            >Log in</button>
          ) : (
            <div ref={userMenuRef} style={{ position: 'relative' }}>
              <button
                onClick={() => setShowUserMenu(v => !v)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 7,
                  background: 'transparent', border: 'none', cursor: 'pointer',
                  padding: '2px 4px', borderRadius: t.radiusPill, transition: 'all 0.15s',
                }}
                onMouseEnter={e => e.currentTarget.style.background = t._selectedHover()}
                onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
              >
                <div style={{
                  width: 28, height: 28, borderRadius: '50%', background: t.accent,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 13, fontWeight: 800, color: accentTextColor, fontFamily: t.fontDisplay,
                  border: `${t.borderW} solid ${t.border}`, boxShadow: '0 1px 3px rgba(0,0,0,0.15)',
                  transition: 'all 0.2s',
                }}>
                  {MOCK_USER.initial}
                </div>
                <span style={{ fontSize: 12, fontWeight: 600, color: t.text, fontFamily: 'inherit' }}>
                  {MOCK_USER.name}
                </span>
                <svg width="10" height="6" viewBox="0 0 10 6" style={{ opacity: 0.5, transition: 'transform 0.2s', transform: showUserMenu ? 'rotate(180deg)' : 'rotate(0)' }}>
                  <path d="M1 1L5 5L9 1" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round" />
                </svg>
              </button>

              <AnimatePresence>
                {showUserMenu && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.92, y: -4 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.92, y: -4 }}
                    transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                    style={{
                      position: 'absolute', top: 'calc(100% + 8px)', right: 0,
                      width: 280, background: t.surface,
                      border: `${t.borderWHeavy} solid ${t.border}`,
                      borderRadius: t.radiusXl, boxShadow: t.modalShadow,
                      overflow: 'hidden', zIndex: 9999,
                    }}
                  >
                    {/* User header */}
                    <div style={{
                      padding: '16px 16px 12px', display: 'flex', alignItems: 'center', gap: 10,
                      borderBottom: `1px solid ${t.borderLight}`,
                    }}>
                      <div style={{
                        width: 36, height: 36, borderRadius: '50%', background: t.accent,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        fontSize: 16, fontWeight: 800, color: accentTextColor, fontFamily: t.fontDisplay,
                        border: `${t.borderW} solid ${t.border}`, flexShrink: 0,
                      }}>
                        {MOCK_USER.initial}
                      </div>
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: 14, fontWeight: 700, color: t.text, fontFamily: t.fontDisplay }}>
                          {MOCK_USER.name}
                        </div>
                        <div style={{ fontSize: 11, color: t.textMuted, fontWeight: 500 }}>
                          {MOCK_FOLLOWING.length} following · {MOCK_FOLLOWERS.length} followers
                        </div>
                      </div>
                    </div>

                    {/* Friends tabs */}
                    <div style={{ display: 'flex', borderBottom: `1px solid ${t.borderLight}` }}>
                      {(['following', 'followers'] as const).map(tab => (
                        <button
                          key={tab}
                          onClick={() => setFriendsTab(tab)}
                          style={{
                            flex: 1, padding: '9px 0', fontSize: 11, fontWeight: 700,
                            textTransform: 'uppercase', letterSpacing: 0.8,
                            background: 'transparent', border: 'none', cursor: 'pointer',
                            color: friendsTab === tab ? t.accent : t.textMuted,
                            borderBottom: friendsTab === tab ? `2px solid ${t.accent}` : '2px solid transparent',
                            fontFamily: 'inherit', transition: 'all 0.15s',
                          }}
                        >
                          {tab === 'following' ? `Following (${MOCK_FOLLOWING.length})` : `Followers (${MOCK_FOLLOWERS.length})`}
                        </button>
                      ))}
                    </div>

                    {/* Friends list */}
                    <div style={{ padding: '6px 0', maxHeight: 180, overflowY: 'auto' }}>
                      {(friendsTab === 'following' ? MOCK_FOLLOWING : MOCK_FOLLOWERS).map((friend, i) => (
                        <motion.div
                          key={friend.name}
                          initial={{ opacity: 0, x: -8 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.04 }}
                          style={{
                            display: 'flex', alignItems: 'center', gap: 10, padding: '7px 16px',
                            cursor: 'pointer', transition: 'background 0.1s',
                          }}
                          onMouseEnter={e => e.currentTarget.style.background = t._selectedHover()}
                          onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                        >
                          <div style={{ position: 'relative' }}>
                            <div style={{
                              width: 26, height: 26, borderRadius: '50%', background: t.selected,
                              display: 'flex', alignItems: 'center', justifyContent: 'center',
                              fontSize: 11, fontWeight: 700, color: t.text,
                              border: `1px solid ${t.borderLight}`,
                            }}>
                              {friend.initial}
                            </div>
                            <div style={{
                              position: 'absolute', bottom: -1, right: -1,
                              width: 8, height: 8, borderRadius: '50%',
                              background: friend.status === 'online' ? '#34D399' : t.borderLight,
                              border: `1.5px solid ${t._surface()}`,
                            }} />
                          </div>
                          <span style={{ fontSize: 13, fontWeight: 600, color: t.text }}>
                            {friend.name}
                          </span>
                        </motion.div>
                      ))}
                    </div>

                    {/* Add friend */}
                    <div style={{ padding: '8px 12px', borderTop: `1px solid ${t.borderLight}` }}>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <input
                          value={addFriendValue}
                          onChange={e => setAddFriendValue(e.target.value)}
                          placeholder="Add by nickname..."
                          style={{
                            flex: 1, background: t.selected, border: `1px solid ${t.borderLight}`,
                            borderRadius: t.radiusMd, padding: '6px 10px', color: t.text,
                            fontSize: 12, fontFamily: 'inherit', outline: 'none',
                          }}
                          onFocus={e => e.currentTarget.style.borderColor = t._accent()}
                          onBlur={e => e.currentTarget.style.borderColor = t._borderLight()}
                        />
                        <button style={{
                          background: t.accent, border: `${t.borderW} solid ${t.border}`,
                          color: accentTextColor, padding: '0 10px', fontSize: 11, fontWeight: 700,
                          borderRadius: t.radiusMd, cursor: 'pointer', fontFamily: 'inherit',
                          whiteSpace: 'nowrap',
                        }}>
                          Add
                        </button>
                      </div>
                    </div>

                    {/* Logout */}
                    <div style={{ padding: '4px 12px 10px' }}>
                      <button
                        onClick={() => { setIsLoggedIn(false); setShowUserMenu(false) }}
                        style={{
                          width: '100%', background: 'transparent', border: `1px solid ${t.borderLight}`,
                          color: t.textMuted, padding: '7px 0', fontSize: 11, fontWeight: 600,
                          borderRadius: t.radiusMd, cursor: 'pointer', fontFamily: 'inherit',
                          transition: 'all 0.15s',
                        }}
                        onMouseEnter={e => { e.currentTarget.style.background = t._selectedHover(); e.currentTarget.style.color = t._text() }}
                        onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = t._textMuted() }}
                      >
                        Log out
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>

      {/* ===== MAIN CANVAS AREA ===== */}
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden', zIndex: 1 }}>
        <div
          onMouseDown={handleCanvasMouseDown}
          onMouseMove={handleCanvasMouseMove}
          onMouseUp={handleCanvasMouseUp}
          onMouseLeave={handleCanvasMouseUp}
          onWheel={handleWheel}
          style={{
            width: '100%', height: '100%',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: isPanning ? 'grabbing' : toolMode === 'select' ? 'default' : 'none',
          }}
        >
          <div
            ref={canvasRef}
            data-canvas
            onMouseDown={toolMode !== 'select' ? handleStampDown : undefined}
            onClick={toolMode === 'select' ? handleCanvasClick : undefined}
            style={{
              width: 800, height: 800, background: bgColor, position: 'relative',
              transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
              transformOrigin: 'center center',
              border: `${t.borderWHeavy} solid ${t.border}`,
              transition: isPanning ? 'none' : `background var(--theme-transition)`,
            }}
          >
            {shapes.filter(s => s.visible !== false).map(shape => (
              <motion.div
                key={shape.id}
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: shape.rotation }}
                transition={{ type: 'spring', stiffness: 400, damping: 15, mass: 0.8 }}
                onClick={(e) => { if (toolMode === 'select') { e.stopPropagation(); selectShape(shape.id, e) } }}
                style={{
                  position: 'absolute',
                  left: shape.x - shape.size / 2, top: shape.y - shape.size / 2,
                  width: shape.size, height: shape.size,
                  background: shape.color,
                  borderRadius: shape.type === 'circle' ? '50%' : t.radiusSm,
                  cursor: toolMode === 'select' ? 'pointer' : 'none',
                }}
              />
            ))}

            {/* Preview shape during stamp drag */}
            {previewShape && (
              <motion.div
                key={`preview-${previewShape.id}`}
                initial={{ scale: 0.6, opacity: 0 }}
                animate={{ scale: 1, opacity: 0.75 }}
                transition={{ type: 'spring', stiffness: 500, damping: 25 }}
                style={{
                  position: 'absolute',
                  left: previewShape.x - previewShape.size / 2,
                  top: previewShape.y - previewShape.size / 2,
                  width: previewShape.size, height: previewShape.size,
                  background: previewShape.color,
                  borderRadius: previewShape.type === 'circle' ? '50%' : t.radiusSm,
                  pointerEvents: 'none',
                }}
              />
            )}

            {/* Empty canvas hint */}
            {shapes.length === 0 && toolMode === 'select' && (
              <div style={{
                position: 'absolute', top: '50%', left: '50%',
                transform: 'translate(-50%, -50%)',
                textAlign: 'center', color: t.textMuted,
                fontSize: 13, fontWeight: 500,
                pointerEvents: 'none', opacity: 0.7,
              }}>
                Pick a shape below to start creating
              </div>
            )}

            {/* Hover highlight from layer panel */}
            {hoveredLayerId && !selectedIds.has(hoveredLayerId) && (() => {
              const hs = shapes.find(s => s.id === hoveredLayerId && s.visible !== false)
              if (!hs) return null
              const pad = 6
              return (
                <div style={{
                  position: 'absolute',
                  left: hs.x - hs.size / 2 - pad, top: hs.y - hs.size / 2 - pad,
                  width: hs.size + pad * 2, height: hs.size + pad * 2,
                  transform: `rotate(${hs.rotation}deg)`,
                  border: '1.5px dashed var(--sel-border)',
                  borderRadius: hs.type === 'circle' ? '50%' : t.radiusSm,
                  background: 'var(--sel-hover-fill)',
                  pointerEvents: 'none',
                  opacity: 0.7,
                  transition: 'all 0.15s ease',
                }} />
              )
            })()}

            {/* Selection overlay for active shape */}
            {selectedShapeId && (() => {
              const ss = shapes.find(s => s.id === selectedShapeId && s.visible !== false)
              if (!ss) return null
              return (
                <SelectionOverlay
                  shape={ss}
                  zoom={zoom}
                  t={t}
                  themeId={themeId}
                  onResize={(newSize) => updateShape(ss.id, { size: newSize })}
                  onRotate={(newRotation) => updateShape(ss.id, { rotation: newRotation })}
                  onMove={(dx, dy) => updateShape(ss.id, { x: ss.x + dx, y: ss.y + dy })}
                  onDragEnd={() => { justDragged.current = true }}
                />
              )
            })()}

            {/* Multi-select outlines */}
            {selectedIds.size > 1 && shapes.filter(s => selectedIds.has(s.id) && s.visible !== false).map(shape => {
              const pad = 4
              return (
                <div key={`sel-${shape.id}`} style={{
                  position: 'absolute',
                  left: shape.x - shape.size / 2 - pad, top: shape.y - shape.size / 2 - pad,
                  width: shape.size + pad * 2, height: shape.size + pad * 2,
                  transform: `rotate(${shape.rotation}deg)`,
                  border: '1.5px solid var(--sel-border)',
                  borderRadius: shape.type === 'circle' ? '50%' : t.radiusSm,
                  pointerEvents: 'none',
                  opacity: 0.6,
                }} />
              )
            })}
          </div>
        </div>

        {/* ===== TOP-LEFT: TOOLS TOGGLE ===== */}
        <AnimatePresence>
          {!showTools && (
            <motion.button
              initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
              onClick={() => setShowTools(true)}
              style={{
                position: 'absolute', left: 12, top: 12,
                width: 40, height: 40, background: t.surface, border: `${t.borderW} solid ${t.border}`,
                borderRadius: t.radiusMd, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                boxShadow: t.btnShadow, zIndex: 50, color: t.textMuted, fontFamily: 'inherit',
              }}
              title="Open tools"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
              </svg>
            </motion.button>
          )}
        </AnimatePresence>

        {/* ===== LEFT TOOLS PANEL ===== */}
        <AnimatePresence>
          {showTools && (
            <motion.div
              initial={{ x: -60, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: -60, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 400, damping: 30 }}
              style={{
                position: 'absolute', left: 12, top: 12, zIndex: 50,
                display: 'flex', flexDirection: 'column', gap: 6, padding: 6,
                background: t.surface, border: `${t.borderW} solid ${t.border}`,
                borderRadius: t.radiusLg, boxShadow: t.cardShadow,
                transition: `background var(--theme-transition)`,
              }}
            >
              <button onClick={() => setShowTools(false)} onMouseEnter={toolBtnHover} onMouseLeave={toolBtnLeave}
                style={toolBtnBase} title="Hide tools">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M15 18l-6-6 6-6"/></svg>
              </button>
              <div style={{ height: 2, background: t.borderLight, borderRadius: 1, margin: '2px 4px' }} />
              <button onClick={undo} onMouseEnter={toolBtnHover} onMouseLeave={toolBtnLeave}
                style={{ ...toolBtnBase, opacity: history.length === 0 ? 0.35 : 1 }} title="Undo (Z)">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 7v6h6"/><path d="M3 13a9 9 0 0 1 3-6.36A9 9 0 0 1 21 12"/></svg>
              </button>
              <button onClick={redo} onMouseEnter={toolBtnHover} onMouseLeave={toolBtnLeave}
                style={{ ...toolBtnBase, opacity: redoStack.length === 0 ? 0.35 : 1 }} title="Redo (Shift+Z)">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 7v6h-6"/><path d="M21 13a9 9 0 0 0-3-6.36A9 9 0 0 0 3 12"/></svg>
              </button>
              <div style={{ height: 2, background: t.borderLight, borderRadius: 1, margin: '2px 4px' }} />
              <button onClick={() => selectedShapeId && duplicateShape(selectedShapeId)} onMouseEnter={toolBtnHover} onMouseLeave={toolBtnLeave}
                style={{ ...toolBtnBase, opacity: selectedShapeId ? 1 : 0.35 }} title="Duplicate (Cmd+D)">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
              </button>
              <button onClick={() => selectedShapeId && deleteShape(selectedShapeId)} onMouseEnter={toolBtnHover} onMouseLeave={toolBtnLeave}
                style={{ ...toolBtnBase, opacity: selectedShapeId ? 1 : 0.35 }} title="Delete (Backspace)">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
              </button>
              <div style={{ height: 2, background: t.borderLight, borderRadius: 1, margin: '2px 4px' }} />
              <button onClick={() => selectedShapeId && moveLayer(selectedShapeId, 'up')} onMouseEnter={toolBtnHover} onMouseLeave={toolBtnLeave}
                style={{ ...toolBtnBase, opacity: selectedShapeId ? 1 : 0.35 }} title="Bring forward">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg>
              </button>
              <button onClick={() => selectedShapeId && moveLayer(selectedShapeId, 'down')} onMouseEnter={toolBtnHover} onMouseLeave={toolBtnLeave}
                style={{ ...toolBtnBase, opacity: selectedShapeId ? 1 : 0.35 }} title="Send backward">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12l7 7 7-7"/></svg>
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ===== RIGHT LAYERS TOGGLE ===== */}
        <AnimatePresence>
          {!showLayers && (
            <motion.button
              initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.2 }}
              onClick={() => setShowLayers(true)}
              style={{
                position: 'absolute', right: 12, top: 12, height: 40, padding: '0 14px',
                background: t.surface, border: `${t.borderW} solid ${t.border}`, borderRadius: t.radiusMd,
                cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
                boxShadow: t.btnShadow, zIndex: 50, fontSize: 12, fontWeight: 600, color: t.text, fontFamily: 'inherit',
              }}
              title="Open layers"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>
              </svg>
              <span>{shapes.length}</span>
            </motion.button>
          )}
        </AnimatePresence>

        {/* ===== RIGHT LAYERS PANEL ===== */}
        <AnimatePresence>
          {showLayers && (
            <motion.div
              initial={{ x: 40, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: 40, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 400, damping: 30 }}
              style={{
                position: 'absolute', right: 12, top: 12, width: 240,
                maxHeight: 'calc(100% - 80px)', zIndex: 50,
                background: t.surface, border: `${t.borderW} solid ${t.border}`, borderRadius: t.radiusLg,
                boxShadow: t.cardShadow, display: 'flex', flexDirection: 'column',
                overflow: 'hidden', transition: `background var(--theme-transition)`,
              }}
            >
              {/* Header */}
              <div style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '10px 12px', borderBottom: `${t.borderW} solid ${t.selected}`, flexShrink: 0,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>
                  </svg>
                  <span style={{ fontSize: 12, fontWeight: 700, letterSpacing: 1 }}>Layers</span>
                  <span style={{ background: t.selected, borderRadius: t.radiusSm, padding: '1px 7px', fontSize: 10, fontWeight: 700, color: t.textMuted }}>{shapes.length}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  {/* Group button */}
                  <button onClick={groupSelected}
                    style={{
                      background: 'none', border: 'none', cursor: selectedIds.size >= 2 ? 'pointer' : 'default',
                      color: t.textMuted, width: 24, height: 24, display: 'flex', alignItems: 'center', justifyContent: 'center',
                      borderRadius: t.radiusSm, opacity: selectedIds.size >= 2 ? 1 : 0.3, transition: 'all 0.15s',
                    }}
                    onMouseEnter={e => { if (selectedIds.size >= 2) e.currentTarget.style.background = t._selected() }}
                    onMouseLeave={e => e.currentTarget.style.background = 'none'}
                    title={selectedIds.size >= 2 ? `Group ${selectedIds.size} layers` : 'Select 2+ layers to group (Shift+click)'}
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                      <rect x="2" y="2" width="8" height="8" rx="1"/><rect x="14" y="14" width="8" height="8" rx="1"/><path d="M10 6h4"/><path d="M6 10v4"/><path d="M14 18h-4"/><path d="M18 14v-4"/>
                    </svg>
                  </button>
                  {/* Close */}
                  <button onClick={() => setShowLayers(false)} style={{
                    background: 'none', border: 'none', cursor: 'pointer', color: t.textMuted,
                    width: 24, height: 24, display: 'flex', alignItems: 'center', justifyContent: 'center',
                    borderRadius: t.radiusSm, fontFamily: 'inherit',
                  }}
                    onMouseEnter={e => e.currentTarget.style.background = t._selected()}
                    onMouseLeave={e => e.currentTarget.style.background = 'none'}
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
                  </button>
                </div>
              </div>

              {/* Layer items */}
              <div style={{ overflowY: 'auto', padding: '4px 6px' }}>
                {/* Render groups first, then ungrouped */}
                {groups.map(group => {
                  const children = groupedShapes(group.id)
                  if (children.length === 0) return null
                  return (
                    <div key={group.id} style={{ marginBottom: 4 }}>
                      {/* Group header */}
                      <div style={{
                        display: 'flex', alignItems: 'center', gap: 6, padding: '5px 8px',
                        background: t.selected, borderRadius: t.radiusSm, marginBottom: 2, cursor: 'pointer',
                      }}
                        onClick={() => toggleGroupCollapse(group.id)}
                      >
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"
                          style={{ transform: group.collapsed ? 'rotate(-90deg)' : 'rotate(0)', transition: 'transform 0.15s' }}>
                          <path d="M6 9l6 6 6-6"/>
                        </svg>
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                          <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
                        </svg>
                        <span style={{ flex: 1, fontSize: 10, fontWeight: 700, color: t.text, letterSpacing: 0.5 }}>
                          {group.name}
                        </span>
                        <span style={{ fontSize: 9, color: t.textMuted, fontWeight: 600 }}>{children.length}</span>
                        <button onClick={(e) => { e.stopPropagation(); ungroupGroup(group.id) }}
                          style={{ background: 'none', border: 'none', cursor: 'pointer', color: t.textMuted, padding: '1px 3px', borderRadius: 4, fontSize: 9, fontFamily: 'inherit', fontWeight: 600 }}
                          onMouseEnter={e => { e.currentTarget.style.background = t._selectedHover(); e.currentTarget.style.color = t._accent() }}
                          onMouseLeave={e => { e.currentTarget.style.background = 'none'; e.currentTarget.style.color = t._textMuted() }}
                          title="Ungroup"
                        >
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                            <rect x="2" y="2" width="8" height="8" rx="1"/><rect x="14" y="14" width="8" height="8" rx="1"/><path d="M10 6h2"/><path d="M6 10v2"/><path d="M14 18h-2"/><path d="M18 14v-2"/>
                          </svg>
                        </button>
                      </div>
                      {/* Group children */}
                      <AnimatePresence>
                        {!group.collapsed && (
                          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
                            style={{ overflow: 'hidden', paddingLeft: 12 }}>
                            {[...children].reverse().map((shape) => (
                              <LayerRow key={shape.id} shape={shape} shapes={shapes} selected={selectedIds.has(shape.id)}
                                onSelect={selectFromLayer} onMove={moveLayer} onDelete={deleteShape} onToggleVisibility={toggleVisibility} t={t}
                                onHover={setHoveredLayerId} />
                            ))}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  )
                })}
                {/* Ungrouped shapes */}
                {[...ungroupedShapes].reverse().map((shape) => (
                  <LayerRow key={shape.id} shape={shape} shapes={shapes} selected={selectedIds.has(shape.id)}
                    onSelect={selectFromLayer} onMove={moveLayer} onDelete={deleteShape} onToggleVisibility={toggleVisibility} t={t}
                    onHover={setHoveredLayerId} />
                ))}
                {shapes.length === 0 && (
                  <div style={{ textAlign: 'center', padding: '20px 8px', fontSize: 12, color: t.textMuted, fontWeight: 500 }}>
                    No shapes yet!<br/>Pick a shape below to start
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ===== ZOOM CONTROLS (bottom-right corner) ===== */}
        <div style={{
          position: 'absolute', bottom: 12, right: 12, display: 'flex', gap: 4, zIndex: 40,
        }}>
          {[
            { label: '+', action: () => setZoom(z => Math.min(4, z * 1.2)) },
            { label: `${Math.round(zoom * 100)}%`, action: () => {} },
            { label: '−', action: () => setZoom(z => Math.max(0.25, z / 1.2)) },
            { label: '1:1', action: () => { setZoom(1); setPan({ x: 0, y: 0 }) } },
          ].map((ctrl, i) => (
            <button key={i} onClick={ctrl.action} style={{
              height: 30, padding: i === 1 ? '0 10px' : '0 8px',
              background: t.surface, border: `${t.borderW} solid ${t.border}`, color: t.text,
              cursor: i === 1 ? 'default' : 'pointer', borderRadius: t.radiusMd,
              fontSize: i === 1 ? 10 : (i === 3 ? 10 : 14), fontWeight: 600, fontFamily: 'inherit',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: t.btnShadow, transition: `background var(--theme-transition)`,
            }}>{ctrl.label}</button>
          ))}
        </div>

        {/* ===== INFO BUTTON (bottom-left corner) ===== */}
        <div style={{ position: 'absolute', bottom: 12, left: 12, zIndex: 40 }}>
          <button
            onClick={() => setShowInfo(!showInfo)}
            style={{
              width: 30, height: 30, background: t.surface, border: `${t.borderW} solid ${t.border}`,
              borderRadius: t.radiusMd, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: t.btnShadow, color: t.textMuted, fontFamily: 'inherit', fontSize: 14, fontWeight: 700,
              transition: `background var(--theme-transition)`,
            }}
            title="Keyboard shortcuts"
          >?</button>

          {/* Info popover */}
          <AnimatePresence>
            {showInfo && (
              <motion.div
                initial={{ opacity: 0, y: 8, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 8, scale: 0.95 }}
                transition={{ duration: 0.15 }}
                style={{
                  position: 'absolute', bottom: 40, left: 0, width: 260,
                  background: t.surface, border: `${t.borderW} solid ${t.border}`, borderRadius: t.radiusLg,
                  boxShadow: t.cardShadow, padding: '14px 16px',
                  transition: `background var(--theme-transition)`,
                }}
              >
                <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase', color: t.text, marginBottom: 10 }}>
                  Keyboard Shortcuts
                </div>
                {[
                  ['V / Esc', 'Select mode'],
                  ['Shift + Click', 'Multi-select'],
                  ['Z', 'Undo'],
                  ['Shift + Z', 'Redo'],
                  ['Backspace / Del', 'Delete selected'],
                  ['Arrow keys', 'Move shape'],
                  ['\u2325 + Drag', 'Pan canvas'],
                  ['Scroll wheel', 'Zoom in/out'],
                ].map(([key, desc]) => (
                  <div key={key} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '3px 0' }}>
                    <span style={{
                      fontSize: 10, fontWeight: 600, color: t.text, background: t.selected,
                      padding: '1px 6px', borderRadius: t.radiusSm, fontFamily: 'inherit',
                    }}>{key}</span>
                    <span style={{ fontSize: 10, color: t.textMuted, fontWeight: 500 }}>{desc}</span>
                  </div>
                ))}
                <div style={{ height: 1, background: t.borderLight, margin: '10px 0 8px' }} />
                <button style={{
                  width: '100%', background: t.selected, border: `1.5px solid ${t.borderLight}`,
                  borderRadius: t.radiusSm, padding: '6px 0', cursor: 'pointer',
                  fontSize: 10, fontWeight: 600, color: t.text, fontFamily: 'inherit',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5,
                  transition: 'all 0.15s',
                }}
                  onMouseEnter={e => { e.currentTarget.style.background = t._selectedHover(); e.currentTarget.style.borderColor = t._border() }}
                  onMouseLeave={e => { e.currentTarget.style.background = t._selected(); e.currentTarget.style.borderColor = t._borderLight() }}
                >
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
                  </svg>
                  Customize shortcuts
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* ===== STAMP MODE HINT ===== */}
      <AnimatePresence>
        {toolMode !== 'select' && (
          <motion.div
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 4 }}
            style={{
              position: 'fixed', bottom: 74, left: 0, right: 0,
              zIndex: 100, display: 'flex', justifyContent: 'center', pointerEvents: 'none',
            }}
          >
            <span style={{
              fontSize: 11, fontWeight: 600, color: t.textMuted,
              background: t.surface, border: `${t.borderW} solid ${t.borderLight}`,
              borderRadius: t.radiusPill, padding: '4px 14px',
              boxShadow: t.cardShadow, fontFamily: t.fontBody,
            }}>
              Click to place &middot; Drag to size &middot; <span style={{ opacity: 0.6 }}>Esc to select</span>
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== FLOATING BOTTOM TOOLBAR PILL ===== */}
      <motion.div
        initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 300, damping: 25, delay: 0.1 }}
        style={{
          position: 'fixed', bottom: 16, left: 0, right: 0,
          zIndex: 100, display: 'flex', justifyContent: 'center', pointerEvents: 'none',
        }}
      >
        <div style={{
          background: t.surface, border: `${t.borderW} solid ${t.border}`,
          borderRadius: t.radiusXl, padding: '6px 16px', height: 48,
          display: 'flex', alignItems: 'center', gap: 6,
          boxShadow: t.cardShadow, backdropFilter: 'blur(12px)',
          transition: `background var(--theme-transition)`, pointerEvents: 'auto',
        }}>
          {/* Tool mode selector */}
          <div style={{
            display: 'flex', gap: 2, background: t.selected,
            borderRadius: t.radiusMd, padding: 2,
          }}>
            {/* Select tool */}
            <button
              onClick={() => setToolMode('select')}
              style={{
                width: 34, height: 34,
                background: toolMode === 'select' ? t.surface : 'transparent',
                border: toolMode === 'select' ? `${t.borderW} solid ${t.border}` : `${t.borderW} solid transparent`,
                borderRadius: t.radiusSm, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'all 0.15s',
                boxShadow: toolMode === 'select' ? t.btnShadow : 'none',
              }}
              onMouseEnter={e => { if (toolMode !== 'select') e.currentTarget.style.background = t._surfaceHover() }}
              onMouseLeave={e => { if (toolMode !== 'select') e.currentTarget.style.background = 'transparent' }}
              title="Select (V)"
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={toolMode === 'select' ? 'var(--text)' : 'var(--text-muted)'} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/>
                <path d="M13 13l6 6"/>
              </svg>
            </button>

            {/* Shape tools */}
            {DAILY_SHAPES.map(shape => (
              <button key={shape} onClick={() => { setToolMode(shape); setSelectedIds(new Set()) }} style={{
                width: 34, height: 34,
                background: toolMode === shape ? t.surface : 'transparent',
                border: toolMode === shape ? `${t.borderW} solid ${t.border}` : `${t.borderW} solid transparent`,
                borderRadius: t.radiusSm, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'all 0.15s',
                boxShadow: toolMode === shape ? t.btnShadow : 'none',
              }}
                onMouseEnter={e => { if (toolMode !== shape) e.currentTarget.style.background = t._surfaceHover() }}
                onMouseLeave={e => { if (toolMode !== shape) e.currentTarget.style.background = 'transparent' }}
                title={`${shape.charAt(0).toUpperCase() + shape.slice(1)}`}
              >
                <div style={{
                  width: 16, height: 16, background: selectedColor,
                  borderRadius: shape === 'circle' ? '50%' : 3,
                  border: `${t.borderW} solid ${t.border}`, transition: 'background 0.15s',
                }} />
              </button>
            ))}
          </div>

          <div style={{ width: 1, height: 24, background: t.borderLight, flexShrink: 0 }} />

          {/* Color selector */}
          <span style={{ fontSize: 9, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase', color: t.textMuted }}>Color</span>
          {DAILY_COLORS.map((color) => (
            <button key={color} onClick={() => setSelectedColor(color)}
              onMouseEnter={() => setHoveredColor(color)} onMouseLeave={() => setHoveredColor(null)}
              style={{
                width: 28, height: 28, background: color,
                border: selectedColor === color ? `${t.borderW} solid ${t.border}` : `${t.borderW} solid transparent`,
                borderRadius: t.radiusSm, cursor: 'pointer', transition: 'all 0.15s',
                transform: (selectedColor === color || hoveredColor === color) ? 'scale(1.15)' : 'scale(1)',
              }}
            />
          ))}

          <div style={{ width: 1, height: 24, background: t.borderLight, flexShrink: 0 }} />

          {/* Background color */}
          <span style={{ fontSize: 9, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase', color: t.textMuted }}>Background</span>
          {[...DAILY_COLORS, '#FFF5F0' as const].map(color => (
            <button key={`bg-${color}`} onClick={() => setBgColor(color)} style={{
              width: 22, height: 22, background: color,
              border: bgColor === color ? `${t.borderW} solid ${t.border}` : `${t.borderW} solid ${t.borderLight}`,
              borderRadius: t.radiusSm, cursor: 'pointer', transition: 'all 0.15s',
            }} />
          ))}
        </div>
      </motion.div>

      {/* ===== GHOST CURSOR (stamp mode) ===== */}
      {toolMode !== 'select' && (
        <div
          ref={ghostRef}
          style={{
            position: 'fixed',
            width: 60, height: 60,
            background: selectedColor,
            borderRadius: toolMode === 'circle' ? '50%' : t.radiusSm,
            opacity: previewShape ? 0 : 0.35,
            pointerEvents: 'none',
            zIndex: 1000,
            transform: 'translate(-50%, -50%)',
            border: `${t.borderW} solid ${t.border}`,
            transition: 'border-radius 0.15s, background 0.15s, opacity 0.1s',
            left: -100, top: -100,
          }}
        />
      )}

      {/* Gallery is now a separate page at /gallery */}
    </div>
  )
}

/* ===== Layer row component ===== */
function LayerRow({ shape, shapes, selected, onSelect, onMove, onDelete, onToggleVisibility, t, onHover }: {
  shape: Shape; shapes: Shape[]; selected: boolean;
  onSelect: (id: string, e?: React.MouseEvent) => void;
  onMove: (id: string, dir: 'up' | 'down') => void;
  onDelete: (id: string) => void;
  onToggleVisibility: (id: string) => void;
  t: ReturnType<typeof useThemeVars>;
  onHover?: (id: string | null) => void;
}) {
  const idx = shapes.indexOf(shape)
  const displayNum = shapes.length - shapes.slice(idx + 1).filter(s => !s.groupId || s.groupId === shape.groupId).length
  return (
    <div
      onClick={(e) => onSelect(shape.id, e)}
      style={{
        display: 'flex', alignItems: 'center', gap: 6,
        padding: '5px 8px', marginBottom: 2,
        background: selected ? t.selected : 'transparent',
        borderRadius: t.radiusMd, cursor: 'pointer', transition: 'background 0.1s',
        opacity: shape.visible === false ? 0.45 : 1,
      }}
      onMouseEnter={e => {
        if (!selected) e.currentTarget.style.background = t._surfaceHover()
        onHover?.(shape.id)
      }}
      onMouseLeave={e => {
        if (!selected) e.currentTarget.style.background = 'transparent'
        onHover?.(null)
      }}
    >
      {/* Visibility toggle */}
      <button onClick={(e) => { e.stopPropagation(); onToggleVisibility(shape.id) }}
        style={{ background: 'none', border: 'none', cursor: 'pointer', color: t.textMuted, padding: '2px 2px', borderRadius: 4, flexShrink: 0, display: 'flex', alignItems: 'center' }}
        onMouseEnter={e => e.currentTarget.style.color = t._text()}
        onMouseLeave={e => e.currentTarget.style.color = t._textMuted()}
        title={shape.visible === false ? 'Show layer' : 'Hide layer'}
      >
        {shape.visible === false ? (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/>
            <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/>
            <line x1="1" y1="1" x2="23" y2="23"/>
          </svg>
        ) : (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
          </svg>
        )}
      </button>
      <div style={{
        width: 18, height: 18, background: shape.color,
        borderRadius: shape.type === 'circle' ? '50%' : t.radiusSm,
        border: `${t.borderW} solid ${t.border}`, flexShrink: 0,
      }} />
      <div style={{ flex: 1, fontSize: 11, fontWeight: 600, color: t.text, textTransform: 'capitalize' }}>
        {shape.type} {displayNum}
      </div>
      <div style={{ display: 'flex', gap: 1 }}>
        <button onClick={(e) => { e.stopPropagation(); onMove(shape.id, 'up') }}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: t.textMuted, padding: '2px 3px', borderRadius: 4 }}
          onMouseEnter={e => e.currentTarget.style.background = t._selectedHover()}
          onMouseLeave={e => e.currentTarget.style.background = 'none'}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg>
        </button>
        <button onClick={(e) => { e.stopPropagation(); onMove(shape.id, 'down') }}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: t.textMuted, padding: '2px 3px', borderRadius: 4 }}
          onMouseEnter={e => e.currentTarget.style.background = t._selectedHover()}
          onMouseLeave={e => e.currentTarget.style.background = 'none'}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12l7 7 7-7"/></svg>
        </button>
        <button onClick={(e) => { e.stopPropagation(); onDelete(shape.id) }}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: t.accent, padding: '2px 3px', borderRadius: 4 }}
          onMouseEnter={e => e.currentTarget.style.background = t._selectedHover()}
          onMouseLeave={e => e.currentTarget.style.background = 'none'}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
      </div>
    </div>
  )
}

/* ===== Selection overlay with resize/rotate handles ===== */
type HandleId = 'nw' | 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w'

const HANDLE_CURSORS: Record<HandleId, string> = {
  nw: 'nwse-resize', n: 'ns-resize', ne: 'nesw-resize', e: 'ew-resize',
  se: 'nwse-resize', s: 'ns-resize', sw: 'nesw-resize', w: 'ew-resize',
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
function SelectionOverlay({ shape, zoom, t, themeId, onResize, onRotate, onMove, onDragEnd }: {
  shape: Shape
  zoom: number
  t: ReturnType<typeof useThemeVars>
  themeId: ThemeId
  onResize: (newSize: number) => void
  onRotate: (newRotation: number) => void
  onMove: (dx: number, dy: number) => void
  onDragEnd?: () => void
}) {
  const dragRef = useRef<{
    type: 'resize' | 'rotate' | 'move'
    handle?: HandleId
    startX: number
    startY: number
    startSize: number
    startRotation: number
    startShapeX: number
    startShapeY: number
    centerX: number
    centerY: number
    committed: boolean
  } | null>(null)

  const pad = 12
  const halfSize = shape.size / 2

  // Handle positions relative to the overlay box
  const handles: { id: HandleId; x: number; y: number }[] = [
    { id: 'nw', x: 0, y: 0 },
    { id: 'n', x: 0.5, y: 0 },
    { id: 'ne', x: 1, y: 0 },
    { id: 'e', x: 1, y: 0.5 },
    { id: 'se', x: 1, y: 1 },
    { id: 's', x: 0.5, y: 1 },
    { id: 'sw', x: 0, y: 1 },
    { id: 'w', x: 0, y: 0.5 },
  ]

  const rotateHandleDistance = 28

  const handleMouseDown = (type: 'resize' | 'rotate' | 'move', handle?: HandleId) => (e: React.MouseEvent) => {
    e.stopPropagation()
    e.preventDefault()
    const rect = (e.currentTarget.closest('[data-canvas]') as HTMLElement)?.getBoundingClientRect()
    if (!rect) return

    const centerX = rect.left + (shape.x * zoom) + (rect.width - 800 * zoom) / 2
    const centerY = rect.top + (shape.y * zoom) + (rect.height - 800 * zoom) / 2

    dragRef.current = {
      type,
      handle,
      startX: e.clientX,
      startY: e.clientY,
      startSize: shape.size,
      startRotation: shape.rotation,
      startShapeX: shape.x,
      startShapeY: shape.y,
      centerX,
      centerY,
      committed: false,
    }

    const handleMouseMove = (ev: MouseEvent) => {
      const d = dragRef.current
      if (!d) return

      if (d.type === 'resize') {
        // Calculate resize delta based on which handle is dragged
        const dx = (ev.clientX - d.startX) / zoom
        const dy = (ev.clientY - d.startY) / zoom
        // Rotate the delta into shape's local space
        const rad = -d.startRotation * Math.PI / 180
        const ldx = dx * Math.cos(rad) - dy * Math.sin(rad)
        const ldy = dx * Math.sin(rad) + dy * Math.cos(rad)

        let sizeDelta = 0
        if (d.handle === 'se') sizeDelta = Math.max(ldx, ldy)
        else if (d.handle === 'nw') sizeDelta = -Math.max(ldx, ldy)
        else if (d.handle === 'ne') sizeDelta = Math.max(ldx, -ldy)
        else if (d.handle === 'sw') sizeDelta = Math.max(-ldx, ldy)
        else if (d.handle === 'e') sizeDelta = ldx
        else if (d.handle === 'w') sizeDelta = -ldx
        else if (d.handle === 's') sizeDelta = ldy
        else if (d.handle === 'n') sizeDelta = -ldy

        const newSize = Math.max(20, d.startSize + sizeDelta)
        onResize(newSize)
      } else if (d.type === 'rotate') {
        const startAngle = Math.atan2(d.startY - d.centerY, d.startX - d.centerX)
        const currentAngle = Math.atan2(ev.clientY - d.centerY, ev.clientX - d.centerX)
        const delta = (currentAngle - startAngle) * 180 / Math.PI
        // Snap to 15-degree increments when holding Shift
        let newRotation = d.startRotation + delta
        if (ev.shiftKey) {
          newRotation = Math.round(newRotation / 15) * 15
        }
        onRotate(newRotation)
      } else if (d.type === 'move') {
        const dx = (ev.clientX - d.startX) / zoom
        const dy = (ev.clientY - d.startY) / zoom
        onMove(dx - (d.committed ? 0 : 0), dy - (d.committed ? 0 : 0))
        d.startX = ev.clientX
        d.startY = ev.clientY
        d.committed = true
      }
    }

    const handleMouseUp = () => {
      dragRef.current = null
      onDragEnd?.()
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)
  }

  // Theme-specific handle radius
  const handleRadius = themeId === 'd' ? '0' : themeId === 'b' ? '1px' : '50%'

  return (
    <div
      style={{
        position: 'absolute',
        left: shape.x - halfSize - pad,
        top: shape.y - halfSize - pad,
        width: shape.size + pad * 2,
        height: shape.size + pad * 2,
        transform: `rotate(${shape.rotation}deg)`,
        pointerEvents: 'none',
      }}
    >
      {/* Selection border — SVG for dash support */}
      <svg
        style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', overflow: 'visible' }}
        viewBox={`0 0 ${shape.size + pad * 2} ${shape.size + pad * 2}`}
      >
        <rect
          x={pad} y={pad}
          width={shape.size} height={shape.size}
          fill="none"
          stroke="var(--sel-border)"
          strokeWidth={themeId === 'd' ? 2.5 : themeId === 'b' ? 1 : 1.5}
          strokeDasharray={themeId === 'b' || themeId === 'd' ? 'var(--sel-dash)' : 'none'}
          rx={shape.type === 'circle' ? shape.size / 2 : (themeId === 'a' ? 8 : themeId === 'c' ? 12 : 0)}
          ry={shape.type === 'circle' ? shape.size / 2 : (themeId === 'a' ? 8 : themeId === 'c' ? 12 : 0)}
          style={{ opacity: 0.8 }}
        />
      </svg>

      {/* Rotation stem + handle */}
      <div
        onMouseDown={handleMouseDown('rotate')}
        style={{
          position: 'absolute',
          left: '50%',
          top: -rotateHandleDistance + pad,
          transform: 'translateX(-50%)',
          display: 'flex', flexDirection: 'column', alignItems: 'center',
          pointerEvents: 'auto',
          cursor: 'grab',
        }}
      >
        {/* Stem line */}
        <div style={{
          width: themeId === 'd' ? 2.5 : 1.5,
          height: rotateHandleDistance - 4,
          background: 'var(--sel-rotate-color)',
          opacity: 0.6,
        }} />
        {/* Rotation knob */}
        <div style={{
          position: 'absolute',
          top: -2,
          width: themeId === 'd' ? 12 : 11,
          height: themeId === 'd' ? 12 : 11,
          borderRadius: themeId === 'd' ? 0 : '50%',
          background: 'var(--sel-rotate-color)',
          border: `2px solid var(--sel-handle-stroke)`,
          boxShadow: themeId === 'a' ? '0 1px 4px rgba(0,0,0,0.2)' :
                     themeId === 'c' ? '0 2px 8px rgba(0,0,0,0.1)' : 'none',
          cursor: 'grab',
        }} />
      </div>

      {/* Resize handles */}
      {handles.map(h => {
        const hx = pad + h.x * shape.size
        const hy = pad + h.y * shape.size
        const isCorner = h.id.length === 2
        const size = isCorner ? 'var(--sel-handle-size)' : 'calc(var(--sel-handle-size) - 2px)'
        return (
          <div
            key={h.id}
            onMouseDown={handleMouseDown('resize', h.id)}
            style={{
              position: 'absolute',
              left: hx, top: hy,
              width: size, height: size,
              transform: 'translate(-50%, -50%)',
              background: 'var(--sel-handle-fill)',
              border: `2px solid var(--sel-handle-stroke)`,
              borderRadius: handleRadius,
              cursor: HANDLE_CURSORS[h.id],
              pointerEvents: 'auto',
              boxShadow: themeId === 'a' ? '0 1px 4px rgba(0,0,0,0.2)' :
                         themeId === 'c' ? '0 2px 8px rgba(0,0,0,0.1)' : 'none',
              transition: 'transform 0.1s',
            }}
            onMouseEnter={e => e.currentTarget.style.transform = 'translate(-50%, -50%) scale(1.3)'}
            onMouseLeave={e => e.currentTarget.style.transform = 'translate(-50%, -50%) scale(1)'}
          />
        )
      })}

      {/* Invisible move zone over the shape itself */}
      <div
        onMouseDown={handleMouseDown('move')}
        style={{
          position: 'absolute',
          left: pad, top: pad,
          width: shape.size, height: shape.size,
          borderRadius: shape.type === 'circle' ? '50%' : (themeId === 'a' ? 8 : themeId === 'c' ? 12 : 0),
          cursor: 'move',
          pointerEvents: 'auto',
        }}
      />
    </div>
  )
}
