// ============================================================
// Mock data for gallery views
// Each day has its own color palette and inspiration word,
// and submissions are procedurally generated "art" thumbnails
// ============================================================

export type MockSubmission = {
  id: string
  artist: string
  date: string          // YYYY-MM-DD
  colors: [string, string, string]
  bgColor: string
  shapes: MockShape[]
  word: string
  rank?: number
  totalSubmissions: number
  isWinner: boolean
  isFriend: boolean
  shapeCount: number
  submittedAt: string   // ISO date string
  liked: boolean
}

export type MockShape = {
  type: 'circle' | 'square'
  color: string
  x: number   // 0-100 percentage
  y: number
  size: number // 0-100 percentage
  rotation: number
}

// Seeded random for deterministic generation
function seededRandom(seed: number) {
  let s = seed
  return () => {
    s = (s * 16807 + 0) % 2147483647
    return (s - 1) / 2147483646
  }
}

const WORDS = [
  'Ephemeral', 'Cascade', 'Drift', 'Bloom', 'Fracture',
  'Whisper', 'Digest', 'Pulse', 'Orbit', 'Ember',
  'Ripple', 'Shard', 'Glow', 'Fold', 'Ascend',
  'Twilight', 'Moss', 'Echo', 'Prism', 'Vapor',
  'Nest', 'Tide', 'Flux', 'Crest', 'Dusk',
  'Reverie', 'Silence', 'Nova', 'Fern', 'Spire',
  'Mirage',
]

const PALETTES: [string, string, string][] = [
  ['#FF3366', '#33CCFF', '#FFCC00'],
  ['#E63322', '#2D1B69', '#33CCFF'],
  ['#CCFF00', '#FF3366', '#111111'],
  ['#E07A5F', '#9DC4B0', '#FFCC00'],
  ['#FF6B35', '#004E89', '#F7C59F'],
  ['#2EC4B6', '#FF6B6B', '#FEE440'],
  ['#7209B7', '#F72585', '#4CC9F0'],
  ['#606C38', '#DDA15E', '#BC6C25'],
  ['#FF9F1C', '#2EC4B6', '#E71D36'],
  ['#6A0572', '#AB83A1', '#F15BB5'],
  ['#00B4D8', '#FF006E', '#FFBE0B'],
  ['#3A86FF', '#FF006E', '#8338EC'],
  ['#EF476F', '#06D6A0', '#118AB2'],
  ['#F4845F', '#F7B267', '#45B7D1'],
  ['#FF5400', '#7B2D8E', '#00B4D8'],
  ['#E9C46A', '#264653', '#E76F51'],
  ['#2B9348', '#FF6700', '#6A0572'],
  ['#FB5607', '#3A0CA3', '#4CC9F0'],
  ['#F72585', '#7209B7', '#3F37C9'],
  ['#FF0A54', '#FF477E', '#FFDDD2'],
  ['#023047', '#FFB703', '#FB8500'],
  ['#D90429', '#EF233C', '#2B2D42'],
  ['#FF4800', '#FF8427', '#540B0E'],
  ['#0081A7', '#F07167', '#FED9B7'],
  ['#00296B', '#FDC500', '#FFD500'],
  ['#8338EC', '#FF006E', '#3A86FF'],
  ['#FF5A5F', '#087E8B', '#C5D86D'],
  ['#F72585', '#B5179E', '#7209B7'],
  ['#00F5D4', '#F15BB5', '#FEE440'],
  ['#264653', '#2A9D8F', '#E9C46A'],
  ['#E63946', '#457B9D', '#A8DADC'],
]

const ARTISTS = [
  'Chris', 'Juls', 'work', 'less', 'mika', 'ava', 'zoe', 'kai',
  'luna', 'nova', 'rox', 'finn', 'sage', 'wren', 'pix', 'dot',
  'ray', 'blu', 'ash', 'ivy',
]

const FRIEND_ARTISTS = ['Juls', 'mika', 'luna', 'finn', 'sage', 'wren']

function getDayData(year: number, month: number, day: number) {
  const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`
  const daySeed = year * 10000 + month * 100 + day
  const rand = seededRandom(daySeed)

  const wordIdx = Math.floor(rand() * WORDS.length)
  const paletteIdx = (month * 31 + day) % PALETTES.length
  const palette = PALETTES[paletteIdx]

  return { dateStr, rand, word: WORDS[wordIdx], palette }
}

function generateShapes(rand: () => number, palette: [string, string, string], count: number): MockShape[] {
  const shapes: MockShape[] = []
  for (let i = 0; i < count; i++) {
    shapes.push({
      type: rand() > 0.5 ? 'circle' : 'square',
      color: palette[Math.floor(rand() * 3)],
      x: rand() * 80 + 10,
      y: rand() * 80 + 10,
      size: rand() * 30 + 8,
      rotation: rand() * 360 - 180,
    })
  }
  return shapes
}

function generateSubmission(
  id: string,
  artist: string,
  dateStr: string,
  word: string,
  palette: [string, string, string],
  rand: () => number,
  rank: number,
  totalSubmissions: number,
): MockSubmission {
  const shapeCount = Math.floor(rand() * 20) + 5
  const bgColorOptions = [palette[0], palette[1], palette[2], '#FFFBF7', '#F0F0E8', '#1A1A2E']
  const bgColor = bgColorOptions[Math.floor(rand() * bgColorOptions.length)]

  return {
    id,
    artist,
    date: dateStr,
    colors: palette,
    bgColor,
    shapes: generateShapes(rand, palette, shapeCount),
    word,
    rank,
    totalSubmissions,
    isWinner: rank === 1,
    isFriend: FRIEND_ARTISTS.includes(artist),
    shapeCount,
    submittedAt: `${dateStr}T${String(Math.floor(rand() * 12) + 8).padStart(2, '0')}:${String(Math.floor(rand() * 60)).padStart(2, '0')}:00Z`,
    liked: rand() > 0.7,
  }
}

// Get all submissions for a given day
export function getSubmissionsForDay(year: number, month: number, day: number): MockSubmission[] {
  const { dateStr, rand, word, palette } = getDayData(year, month, day)
  const today = new Date()
  const date = new Date(year, month - 1, day)

  // Future days have no submissions
  if (date > today) return []

  // Today is special: might be in "creating" phase
  if (date.toDateString() === today.toDateString()) {
    // Only return submissions if it's past noon
    if (today.getHours() < 12) return []
  }

  const numSubmissions = Math.floor(rand() * 6) + 1
  const submissions: MockSubmission[] = []

  // Pick random artists for this day
  const dayArtists = [...ARTISTS].sort(() => rand() - 0.5).slice(0, numSubmissions)

  for (let i = 0; i < numSubmissions; i++) {
    submissions.push(
      generateSubmission(
        `sub-${dateStr}-${i}`,
        dayArtists[i],
        dateStr,
        word,
        palette,
        seededRandom(year * 100000 + month * 1000 + day * 100 + i * 7),
        i + 1,
        numSubmissions,
      )
    )
  }

  return submissions
}

// Get user's submission for a given day (if any)
export function getUserSubmission(year: number, month: number, day: number): MockSubmission | null {
  const { dateStr, word, palette } = getDayData(year, month, day)
  const today = new Date()
  const date = new Date(year, month - 1, day)

  if (date > today) return null
  // Today only has a submission after noon
  if (date.toDateString() === today.toDateString() && today.getHours() < 12) return null

  // Use a simple hash that gives good distribution across days
  // User submits about 50% of days
  const hash = ((day * 7 + month * 13 + year * 3) % 100)
  if (hash >= 50) return null

  const daySeed = year * 10000 + month * 100 + day + 42
  const rand = seededRandom(daySeed)

  const allSubs = getSubmissionsForDay(year, month, day)
  const totalSubs = allSubs.length + 1
  const rank = Math.floor(rand() * totalSubs) + 1

  return generateSubmission(
    `user-${dateStr}`,
    'You',
    dateStr,
    word,
    palette,
    seededRandom(daySeed + 999),
    rank,
    totalSubs,
  )
}

// Get the winner for a given day
export function getWinner(year: number, month: number, day: number): MockSubmission | null {
  const subs = getSubmissionsForDay(year, month, day)
  if (subs.length === 0) return null

  const today = new Date()
  const date = new Date(year, month - 1, day)

  // No winner for today or yesterday (voting still ongoing)
  const daysDiff = Math.floor((today.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))
  if (daysDiff < 2) return null

  return subs[0] // First submission is the "winner"
}

// Get day status for the Wall calendar view
export function getDayStatus(year: number, month: number, day: number): {
  count: number
  colors: string[]
  status: 'past' | 'today' | 'future' | 'voting'
} {
  const today = new Date()
  const date = new Date(year, month - 1, day)
  const daysDiff = Math.floor((today.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))

  if (date > today) return { count: 0, colors: [], status: 'future' }
  if (date.toDateString() === today.toDateString()) return { count: 0, colors: [], status: 'today' }
  if (daysDiff === 1) {
    const subs = getSubmissionsForDay(year, month, day)
    return { count: subs.length, colors: getDayData(year, month, day).palette.slice(), status: 'voting' }
  }

  const subs = getSubmissionsForDay(year, month, day)
  return {
    count: subs.length,
    colors: getDayData(year, month, day).palette.slice(),
    status: 'past',
  }
}

// Get friends' submissions for a given day
export function getFriendSubmissions(year: number, month: number, day: number): MockSubmission[] {
  const subs = getSubmissionsForDay(year, month, day)
  return subs.filter(s => FRIEND_ARTISTS.includes(s.artist))
}

// Get all friends' recent submissions (for grid view)
export function getAllFriendSubmissions(year: number, month: number): MockSubmission[] {
  const results: MockSubmission[] = []
  const today = new Date()
  const daysInMonth = new Date(year, month, 0).getDate()

  for (let d = 1; d <= daysInMonth; d++) {
    const date = new Date(year, month - 1, d)
    if (date > today) break
    results.push(...getFriendSubmissions(year, month, d))
  }

  return results.reverse()
}

// Get a single submission by ID
export function getSubmissionById(id: string): MockSubmission | null {
  // Parse the date from the ID
  const match = id.match(/^(?:sub|user)-(\d{4})-(\d{2})-(\d{2})-?(\d*)$/)
  if (!match) return null

  const [, yearStr, monthStr, dayStr] = match
  const year = parseInt(yearStr)
  const month = parseInt(monthStr)
  const day = parseInt(dayStr)

  if (id.startsWith('user-')) {
    return getUserSubmission(year, month, day)
  }

  const subs = getSubmissionsForDay(year, month, day)
  return subs.find(s => s.id === id) || null
}

// Calendar utility
export function getCalendarDays(year: number, month: number): (number | null)[] {
  const firstDay = new Date(year, month - 1, 1).getDay()
  // Convert Sunday=0 to Monday-first: Mon=0, Tue=1, ..., Sun=6
  const startOffset = firstDay === 0 ? 6 : firstDay - 1
  const daysInMonth = new Date(year, month, 0).getDate()

  const days: (number | null)[] = []
  for (let i = 0; i < startOffset; i++) days.push(null)
  for (let d = 1; d <= daysInMonth; d++) days.push(d)
  // Pad to complete last week
  while (days.length % 7 !== 0) days.push(null)

  return days
}

// Get user trophy counts for a month
export function getUserTrophies(year: number, month: number): { gold: number; silver: number; bronze: number } {
  let gold = 0, silver = 0, bronze = 0
  const daysInMonth = new Date(year, month, 0).getDate()

  for (let d = 1; d <= daysInMonth; d++) {
    const sub = getUserSubmission(year, month, d)
    if (!sub) continue
    if (sub.rank === 1) gold++
    else if (sub.rank === 2) silver++
    else if (sub.rank === 3) bronze++
  }

  return { gold, silver, bronze }
}

// Count user submissions for a month
export function getUserSubmissionCount(year: number, month: number): number {
  let count = 0
  const daysInMonth = new Date(year, month, 0).getDate()
  const today = new Date()

  for (let d = 1; d <= daysInMonth; d++) {
    const date = new Date(year, month - 1, d)
    if (date > today) break
    if (getUserSubmission(year, month, d)) count++
  }

  return count
}

// Count winners for a month
export function getWinnerCount(year: number, month: number): { total: number; unique: number } {
  const winners = new Set<string>()
  let total = 0
  const daysInMonth = new Date(year, month, 0).getDate()

  for (let d = 1; d <= daysInMonth; d++) {
    const w = getWinner(year, month, d)
    if (w) {
      total++
      winners.add(w.artist)
    }
  }

  return { total, unique: winners.size }
}
