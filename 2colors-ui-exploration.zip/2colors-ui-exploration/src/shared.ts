import { useEffect } from 'react'

export const DAILY_COLORS = ['#FF3366', '#33CCFF', '#FFCC00'] as const
export const DAILY_SHAPES = ['circle', 'square'] as const
export const DAILY_WORD = 'Ephemeral'

export type ThemeId = 'a' | 'b' | 'c' | 'd'

export const THEME_LABELS: Record<ThemeId, string> = {
  a: 'Pop Art',
  b: 'Swiss',
  c: 'Cloud',
  d: 'Brutal',
}

export function useThemeVars(darkMode: boolean, themeId: ThemeId) {
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', themeId)
    document.documentElement.setAttribute('data-mode', darkMode ? 'dark' : 'light')
  }, [darkMode, themeId])

  const read = (name: string) => {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim()
  }

  return {
    bg:             'var(--bg)',
    surface:        'var(--surface)',
    surfaceHover:   'var(--surface-hover)',
    border:         'var(--border)',
    borderLight:    'var(--border-light)',
    text:           'var(--text)',
    textMuted:      'var(--text-muted)',
    accent:         'var(--accent)',
    accentText:     'var(--accent-text)',
    selected:       'var(--selected)',
    selectedHover:  'var(--selected-hover)',
    patternOpacity: 'var(--pattern-opacity)',
    cardShadow:     'var(--card-shadow)',
    btnShadow:      'var(--btn-shadow)',
    modalShadow:    'var(--modal-shadow)',
    overlay:        'var(--overlay)',
    darkmodeBtnBg:  'var(--darkmode-btn-bg)',
    fontBody:       'var(--font-body)',
    fontDisplay:    'var(--font-display)',
    radiusSm:       'var(--radius-sm)',
    radiusMd:       'var(--radius-md)',
    radiusLg:       'var(--radius-lg)',
    radiusXl:       'var(--radius-xl)',
    radius2xl:      'var(--radius-2xl)',
    radiusPill:     'var(--radius-pill)',
    borderW:        'var(--border-w)',
    borderWHeavy:   'var(--border-w-heavy)',
    patternImage:   'var(--pattern-image)',
    patternSize:    'var(--pattern-size)',
    _surface:       () => read('--surface'),
    _surfaceHover:  () => read('--surface-hover'),
    _border:        () => read('--border'),
    _borderLight:   () => read('--border-light'),
    _text:          () => read('--text'),
    _textMuted:     () => read('--text-muted'),
    _accent:        () => read('--accent'),
    _selected:      () => read('--selected'),
    _selectedHover: () => read('--selected-hover'),
    _btnShadow:     () => read('--btn-shadow'),
    _cardShadow:    () => read('--card-shadow'),
  }
}

export function getAccentTextColor(themeId: ThemeId) {
  return themeId === 'd' ? '#111111' : '#fff'
}
